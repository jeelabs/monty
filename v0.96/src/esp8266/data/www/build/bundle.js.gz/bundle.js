
(function(l, r) { if (l.getElementById('livereloadscript')) return; r = l.createElement('script'); r.async = 1; r.src = '//' + (window.location.host || 'localhost').split(':')[0] + ':35729/livereload.js?snipver=1'; r.id = 'livereloadscript'; l.getElementsByTagName('head')[0].appendChild(r) })(window.document);
var app = (function () {
    'use strict';

    function noop() { }
    function add_location(element, file, line, column, char) {
        element.__svelte_meta = {
            loc: { file, line, column, char }
        };
    }
    function run(fn) {
        return fn();
    }
    function blank_object() {
        return Object.create(null);
    }
    function run_all(fns) {
        fns.forEach(run);
    }
    function is_function(thing) {
        return typeof thing === 'function';
    }
    function safe_not_equal(a, b) {
        return a != a ? b == b : a !== b || ((a && typeof a === 'object') || typeof a === 'function');
    }

    function append(target, node) {
        target.appendChild(node);
    }
    function insert(target, node, anchor) {
        target.insertBefore(node, anchor || null);
    }
    function detach(node) {
        node.parentNode.removeChild(node);
    }
    function destroy_each(iterations, detaching) {
        for (let i = 0; i < iterations.length; i += 1) {
            if (iterations[i])
                iterations[i].d(detaching);
        }
    }
    function element(name) {
        return document.createElement(name);
    }
    function svg_element(name) {
        return document.createElementNS('http://www.w3.org/2000/svg', name);
    }
    function text(data) {
        return document.createTextNode(data);
    }
    function space() {
        return text(' ');
    }
    function empty() {
        return text('');
    }
    function listen(node, event, handler, options) {
        node.addEventListener(event, handler, options);
        return () => node.removeEventListener(event, handler, options);
    }
    function prevent_default(fn) {
        return function (event) {
            event.preventDefault();
            // @ts-ignore
            return fn.call(this, event);
        };
    }
    function stop_propagation(fn) {
        return function (event) {
            event.stopPropagation();
            // @ts-ignore
            return fn.call(this, event);
        };
    }
    function attr(node, attribute, value) {
        if (value == null)
            node.removeAttribute(attribute);
        else if (node.getAttribute(attribute) !== value)
            node.setAttribute(attribute, value);
    }
    function children(element) {
        return Array.from(element.childNodes);
    }
    function set_input_value(input, value) {
        if (value != null || input.value) {
            input.value = value;
        }
    }
    function set_style(node, key, value, important) {
        node.style.setProperty(key, value, important ? 'important' : '');
    }
    function toggle_class(element, name, toggle) {
        element.classList[toggle ? 'add' : 'remove'](name);
    }
    function custom_event(type, detail) {
        const e = document.createEvent('CustomEvent');
        e.initCustomEvent(type, false, false, detail);
        return e;
    }

    let current_component;
    function set_current_component(component) {
        current_component = component;
    }
    function get_current_component() {
        if (!current_component)
            throw new Error(`Function called outside component initialization`);
        return current_component;
    }
    function onMount(fn) {
        get_current_component().$$.on_mount.push(fn);
    }
    function afterUpdate(fn) {
        get_current_component().$$.after_update.push(fn);
    }
    function onDestroy(fn) {
        get_current_component().$$.on_destroy.push(fn);
    }
    function createEventDispatcher() {
        const component = get_current_component();
        return (type, detail) => {
            const callbacks = component.$$.callbacks[type];
            if (callbacks) {
                // TODO are there situations where events could be dispatched
                // in a server (non-DOM) environment?
                const event = custom_event(type, detail);
                callbacks.slice().forEach(fn => {
                    fn.call(component, event);
                });
            }
        };
    }
    function setContext(key, context) {
        get_current_component().$$.context.set(key, context);
    }
    function getContext(key) {
        return get_current_component().$$.context.get(key);
    }

    const dirty_components = [];
    const binding_callbacks = [];
    const render_callbacks = [];
    const flush_callbacks = [];
    const resolved_promise = Promise.resolve();
    let update_scheduled = false;
    function schedule_update() {
        if (!update_scheduled) {
            update_scheduled = true;
            resolved_promise.then(flush);
        }
    }
    function add_render_callback(fn) {
        render_callbacks.push(fn);
    }
    function add_flush_callback(fn) {
        flush_callbacks.push(fn);
    }
    let flushing = false;
    const seen_callbacks = new Set();
    function flush() {
        if (flushing)
            return;
        flushing = true;
        do {
            // first, call beforeUpdate functions
            // and update components
            for (let i = 0; i < dirty_components.length; i += 1) {
                const component = dirty_components[i];
                set_current_component(component);
                update(component.$$);
            }
            dirty_components.length = 0;
            while (binding_callbacks.length)
                binding_callbacks.pop()();
            // then, once components are updated, call
            // afterUpdate functions. This may cause
            // subsequent updates...
            for (let i = 0; i < render_callbacks.length; i += 1) {
                const callback = render_callbacks[i];
                if (!seen_callbacks.has(callback)) {
                    // ...so guard against infinite loops
                    seen_callbacks.add(callback);
                    callback();
                }
            }
            render_callbacks.length = 0;
        } while (dirty_components.length);
        while (flush_callbacks.length) {
            flush_callbacks.pop()();
        }
        update_scheduled = false;
        flushing = false;
        seen_callbacks.clear();
    }
    function update($$) {
        if ($$.fragment !== null) {
            $$.update();
            run_all($$.before_update);
            const dirty = $$.dirty;
            $$.dirty = [-1];
            $$.fragment && $$.fragment.p($$.ctx, dirty);
            $$.after_update.forEach(add_render_callback);
        }
    }
    const outroing = new Set();
    let outros;
    function group_outros() {
        outros = {
            r: 0,
            c: [],
            p: outros // parent group
        };
    }
    function check_outros() {
        if (!outros.r) {
            run_all(outros.c);
        }
        outros = outros.p;
    }
    function transition_in(block, local) {
        if (block && block.i) {
            outroing.delete(block);
            block.i(local);
        }
    }
    function transition_out(block, local, detach, callback) {
        if (block && block.o) {
            if (outroing.has(block))
                return;
            outroing.add(block);
            outros.c.push(() => {
                outroing.delete(block);
                if (callback) {
                    if (detach)
                        block.d(1);
                    callback();
                }
            });
            block.o(local);
        }
    }

    const globals = (typeof window !== 'undefined'
        ? window
        : typeof globalThis !== 'undefined'
            ? globalThis
            : global);
    function outro_and_destroy_block(block, lookup) {
        transition_out(block, 1, 1, () => {
            lookup.delete(block.key);
        });
    }
    function update_keyed_each(old_blocks, dirty, get_key, dynamic, ctx, list, lookup, node, destroy, create_each_block, next, get_context) {
        let o = old_blocks.length;
        let n = list.length;
        let i = o;
        const old_indexes = {};
        while (i--)
            old_indexes[old_blocks[i].key] = i;
        const new_blocks = [];
        const new_lookup = new Map();
        const deltas = new Map();
        i = n;
        while (i--) {
            const child_ctx = get_context(ctx, list, i);
            const key = get_key(child_ctx);
            let block = lookup.get(key);
            if (!block) {
                block = create_each_block(key, child_ctx);
                block.c();
            }
            else if (dynamic) {
                block.p(child_ctx, dirty);
            }
            new_lookup.set(key, new_blocks[i] = block);
            if (key in old_indexes)
                deltas.set(key, Math.abs(i - old_indexes[key]));
        }
        const will_move = new Set();
        const did_move = new Set();
        function insert(block) {
            transition_in(block, 1);
            block.m(node, next, lookup.has(block.key));
            lookup.set(block.key, block);
            next = block.first;
            n--;
        }
        while (o && n) {
            const new_block = new_blocks[n - 1];
            const old_block = old_blocks[o - 1];
            const new_key = new_block.key;
            const old_key = old_block.key;
            if (new_block === old_block) {
                // do nothing
                next = new_block.first;
                o--;
                n--;
            }
            else if (!new_lookup.has(old_key)) {
                // remove old block
                destroy(old_block, lookup);
                o--;
            }
            else if (!lookup.has(new_key) || will_move.has(new_key)) {
                insert(new_block);
            }
            else if (did_move.has(old_key)) {
                o--;
            }
            else if (deltas.get(new_key) > deltas.get(old_key)) {
                did_move.add(new_key);
                insert(new_block);
            }
            else {
                will_move.add(old_key);
                o--;
            }
        }
        while (o--) {
            const old_block = old_blocks[o];
            if (!new_lookup.has(old_block.key))
                destroy(old_block, lookup);
        }
        while (n)
            insert(new_blocks[n - 1]);
        return new_blocks;
    }
    function validate_each_keys(ctx, list, get_context, get_key) {
        const keys = new Set();
        for (let i = 0; i < list.length; i++) {
            const key = get_key(get_context(ctx, list, i));
            if (keys.has(key)) {
                throw new Error(`Cannot have duplicate keys in a keyed each`);
            }
            keys.add(key);
        }
    }

    function bind(component, name, callback) {
        const index = component.$$.props[name];
        if (index !== undefined) {
            component.$$.bound[index] = callback;
            callback(component.$$.ctx[index]);
        }
    }
    function create_component(block) {
        block && block.c();
    }
    function mount_component(component, target, anchor) {
        const { fragment, on_mount, on_destroy, after_update } = component.$$;
        fragment && fragment.m(target, anchor);
        // onMount happens before the initial afterUpdate
        add_render_callback(() => {
            const new_on_destroy = on_mount.map(run).filter(is_function);
            if (on_destroy) {
                on_destroy.push(...new_on_destroy);
            }
            else {
                // Edge case - component was destroyed immediately,
                // most likely as a result of a binding initialising
                run_all(new_on_destroy);
            }
            component.$$.on_mount = [];
        });
        after_update.forEach(add_render_callback);
    }
    function destroy_component(component, detaching) {
        const $$ = component.$$;
        if ($$.fragment !== null) {
            run_all($$.on_destroy);
            $$.fragment && $$.fragment.d(detaching);
            // TODO null out other refs, including component.$$ (but need to
            // preserve final state?)
            $$.on_destroy = $$.fragment = null;
            $$.ctx = [];
        }
    }
    function make_dirty(component, i) {
        if (component.$$.dirty[0] === -1) {
            dirty_components.push(component);
            schedule_update();
            component.$$.dirty.fill(0);
        }
        component.$$.dirty[(i / 31) | 0] |= (1 << (i % 31));
    }
    function init(component, options, instance, create_fragment, not_equal, props, dirty = [-1]) {
        const parent_component = current_component;
        set_current_component(component);
        const prop_values = options.props || {};
        const $$ = component.$$ = {
            fragment: null,
            ctx: null,
            // state
            props,
            update: noop,
            not_equal,
            bound: blank_object(),
            // lifecycle
            on_mount: [],
            on_destroy: [],
            before_update: [],
            after_update: [],
            context: new Map(parent_component ? parent_component.$$.context : []),
            // everything else
            callbacks: blank_object(),
            dirty
        };
        let ready = false;
        $$.ctx = instance
            ? instance(component, prop_values, (i, ret, ...rest) => {
                const value = rest.length ? rest[0] : ret;
                if ($$.ctx && not_equal($$.ctx[i], $$.ctx[i] = value)) {
                    if ($$.bound[i])
                        $$.bound[i](value);
                    if (ready)
                        make_dirty(component, i);
                }
                return ret;
            })
            : [];
        $$.update();
        ready = true;
        run_all($$.before_update);
        // `false` as a special case of no DOM component
        $$.fragment = create_fragment ? create_fragment($$.ctx) : false;
        if (options.target) {
            if (options.hydrate) {
                const nodes = children(options.target);
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                $$.fragment && $$.fragment.l(nodes);
                nodes.forEach(detach);
            }
            else {
                // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
                $$.fragment && $$.fragment.c();
            }
            if (options.intro)
                transition_in(component.$$.fragment);
            mount_component(component, options.target, options.anchor);
            flush();
        }
        set_current_component(parent_component);
    }
    class SvelteComponent {
        $destroy() {
            destroy_component(this, 1);
            this.$destroy = noop;
        }
        $on(type, callback) {
            const callbacks = (this.$$.callbacks[type] || (this.$$.callbacks[type] = []));
            callbacks.push(callback);
            return () => {
                const index = callbacks.indexOf(callback);
                if (index !== -1)
                    callbacks.splice(index, 1);
            };
        }
        $set() {
            // overridden by instance, if it has props
        }
    }

    function dispatch_dev(type, detail) {
        document.dispatchEvent(custom_event(type, Object.assign({ version: '3.21.0' }, detail)));
    }
    function append_dev(target, node) {
        dispatch_dev("SvelteDOMInsert", { target, node });
        append(target, node);
    }
    function insert_dev(target, node, anchor) {
        dispatch_dev("SvelteDOMInsert", { target, node, anchor });
        insert(target, node, anchor);
    }
    function detach_dev(node) {
        dispatch_dev("SvelteDOMRemove", { node });
        detach(node);
    }
    function listen_dev(node, event, handler, options, has_prevent_default, has_stop_propagation) {
        const modifiers = options === true ? ["capture"] : options ? Array.from(Object.keys(options)) : [];
        if (has_prevent_default)
            modifiers.push('preventDefault');
        if (has_stop_propagation)
            modifiers.push('stopPropagation');
        dispatch_dev("SvelteDOMAddEventListener", { node, event, handler, modifiers });
        const dispose = listen(node, event, handler, options);
        return () => {
            dispatch_dev("SvelteDOMRemoveEventListener", { node, event, handler, modifiers });
            dispose();
        };
    }
    function attr_dev(node, attribute, value) {
        attr(node, attribute, value);
        if (value == null)
            dispatch_dev("SvelteDOMRemoveAttribute", { node, attribute });
        else
            dispatch_dev("SvelteDOMSetAttribute", { node, attribute, value });
    }
    function prop_dev(node, property, value) {
        node[property] = value;
        dispatch_dev("SvelteDOMSetProperty", { node, property, value });
    }
    function set_data_dev(text, data) {
        data = '' + data;
        if (text.data === data)
            return;
        dispatch_dev("SvelteDOMSetData", { node: text, data });
        text.data = data;
    }
    function validate_each_argument(arg) {
        if (typeof arg !== 'string' && !(arg && typeof arg === 'object' && 'length' in arg)) {
            let msg = '{#each} only iterates over array-like objects.';
            if (typeof Symbol === 'function' && arg && Symbol.iterator in arg) {
                msg += ' You can use a spread to convert this iterable into an array.';
            }
            throw new Error(msg);
        }
    }
    function validate_slots(name, slot, keys) {
        for (const slot_key of Object.keys(slot)) {
            if (!~keys.indexOf(slot_key)) {
                console.warn(`<${name}> received an unexpected slot "${slot_key}".`);
            }
        }
    }
    class SvelteComponentDev extends SvelteComponent {
        constructor(options) {
            if (!options || (!options.target && !options.$$inline)) {
                throw new Error(`'target' is a required option`);
            }
            super();
        }
        $destroy() {
            super.$destroy();
            this.$destroy = () => {
                console.warn(`Component was already destroyed`); // eslint-disable-line no-console
            };
        }
        $capture_state() { }
        $inject_state() { }
    }

    /* src/Dashboard.svelte generated by Svelte v3.21.0 */

    const file = "src/Dashboard.svelte";

    function get_each_context(ctx, list, i) {
    	const child_ctx = ctx.slice();
    	child_ctx[2] = list[i];
    	child_ctx[4] = i;
    	return child_ctx;
    }

    // (10:4) {#each Array(30) as _, i}
    function create_each_block(ctx) {
    	let div;
    	let t0;
    	let t1;
    	let t2;

    	const block = {
    		c: function create() {
    			div = element("div");
    			t0 = text("Item ");
    			t1 = text(/*i*/ ctx[4]);
    			t2 = space();
    			attr_dev(div, "class", "box svelte-d17xza");
    			set_style(div, "grid-column-end", "span " + (/*i*/ ctx[4] % 4 + 1));
    			set_style(div, "grid-row-end", "span " + (/*i*/ ctx[4] * 7 % 3 + 1));
    			add_location(div, file, 10, 8, 185);
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, div, anchor);
    			append_dev(div, t0);
    			append_dev(div, t1);
    			append_dev(div, t2);
    		},
    		p: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(div);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_each_block.name,
    		type: "each",
    		source: "(10:4) {#each Array(30) as _, i}",
    		ctx
    	});

    	return block;
    }

    function create_fragment(ctx) {
    	let p;
    	let label;
    	let input;
    	let t0;
    	let t1;
    	let main;
    	let dispose;
    	let each_value = Array(30);
    	validate_each_argument(each_value);
    	let each_blocks = [];

    	for (let i = 0; i < each_value.length; i += 1) {
    		each_blocks[i] = create_each_block(get_each_context(ctx, each_value, i));
    	}

    	const block = {
    		c: function create() {
    			p = element("p");
    			label = element("label");
    			input = element("input");
    			t0 = text(" Dense layout");
    			t1 = space();
    			main = element("main");

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].c();
    			}

    			attr_dev(input, "type", "checkbox");
    			add_location(input, file, 5, 11, 58);
    			add_location(label, file, 5, 4, 51);
    			add_location(p, file, 4, 0, 43);
    			attr_dev(main, "class", "svelte-d17xza");
    			toggle_class(main, "dense", /*dense*/ ctx[0]);
    			add_location(main, file, 8, 0, 128);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor, remount) {
    			insert_dev(target, p, anchor);
    			append_dev(p, label);
    			append_dev(label, input);
    			input.checked = /*dense*/ ctx[0];
    			append_dev(label, t0);
    			insert_dev(target, t1, anchor);
    			insert_dev(target, main, anchor);

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].m(main, null);
    			}

    			if (remount) dispose();
    			dispose = listen_dev(input, "change", /*input_change_handler*/ ctx[1]);
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*dense*/ 1) {
    				input.checked = /*dense*/ ctx[0];
    			}

    			if (dirty & /*dense*/ 1) {
    				toggle_class(main, "dense", /*dense*/ ctx[0]);
    			}
    		},
    		i: noop,
    		o: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(p);
    			if (detaching) detach_dev(t1);
    			if (detaching) detach_dev(main);
    			destroy_each(each_blocks, detaching);
    			dispose();
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function instance($$self, $$props, $$invalidate) {
    	let dense = false;
    	const writable_props = [];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<Dashboard> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("Dashboard", $$slots, []);

    	function input_change_handler() {
    		dense = this.checked;
    		$$invalidate(0, dense);
    	}

    	$$self.$capture_state = () => ({ dense });

    	$$self.$inject_state = $$props => {
    		if ("dense" in $$props) $$invalidate(0, dense = $$props.dense);
    	};

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	return [dense, input_change_handler];
    }

    class Dashboard extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance, create_fragment, safe_not_equal, {});

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "Dashboard",
    			options,
    			id: create_fragment.name
    		});
    	}
    }

    /* src/G_bang.svelte generated by Svelte v3.21.0 */
    const file$1 = "src/G_bang.svelte";

    function create_fragment$1(ctx) {
    	let circle0;
    	let t;
    	let circle1;
    	let dispose;

    	const block = {
    		c: function create() {
    			circle0 = svg_element("circle");
    			t = space();
    			circle1 = svg_element("circle");
    			attr_dev(circle0, "cx", /*cx*/ ctx[1]);
    			attr_dev(circle0, "cy", /*cy*/ ctx[2]);
    			attr_dev(circle0, "r", "10");
    			attr_dev(circle0, "class", "svelte-shlms7");
    			add_location(circle0, file$1, 16, 0, 315);
    			attr_dev(circle1, "class", "inner svelte-shlms7");
    			attr_dev(circle1, "cx", /*cx*/ ctx[1]);
    			attr_dev(circle1, "cy", /*cy*/ ctx[2]);
    			attr_dev(circle1, "r", "7");
    			toggle_class(circle1, "on", /*info*/ ctx[0].value);
    			add_location(circle1, file$1, 17, 0, 341);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor, remount) {
    			insert_dev(target, circle0, anchor);
    			insert_dev(target, t, anchor);
    			insert_dev(target, circle1, anchor);
    			if (remount) dispose();
    			dispose = listen_dev(circle1, "mousedown", stop_propagation(prevent_default(/*onMouseDown*/ ctx[3])), false, true, true);
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*cx*/ 2) {
    				attr_dev(circle0, "cx", /*cx*/ ctx[1]);
    			}

    			if (dirty & /*cy*/ 4) {
    				attr_dev(circle0, "cy", /*cy*/ ctx[2]);
    			}

    			if (dirty & /*cx*/ 2) {
    				attr_dev(circle1, "cx", /*cx*/ ctx[1]);
    			}

    			if (dirty & /*cy*/ 4) {
    				attr_dev(circle1, "cy", /*cy*/ ctx[2]);
    			}

    			if (dirty & /*info*/ 1) {
    				toggle_class(circle1, "on", /*info*/ ctx[0].value);
    			}
    		},
    		i: noop,
    		o: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(circle0);
    			if (detaching) detach_dev(t);
    			if (detaching) detach_dev(circle1);
    			dispose();
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$1.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function instance$1($$self, $$props, $$invalidate) {
    	const sendMsg = getContext("sendMsg");
    	let { info } = $$props;

    	function onMouseDown(e) {
    		sendMsg(info.id, "d", 0, []);
    	}

    	const writable_props = ["info"];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<G_bang> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("G_bang", $$slots, []);

    	$$self.$set = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    	};

    	$$self.$capture_state = () => ({
    		getContext,
    		sendMsg,
    		info,
    		onMouseDown,
    		cx,
    		cy
    	});

    	$$self.$inject_state = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    		if ("cx" in $$props) $$invalidate(1, cx = $$props.cx);
    		if ("cy" in $$props) $$invalidate(2, cy = $$props.cy);
    	};

    	let cx;
    	let cy;

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	$$self.$$.update = () => {
    		if ($$self.$$.dirty & /*info*/ 1) {
    			 if (info.value) setTimeout(
    				() => {
    					$$invalidate(0, info.value = false, info);
    				},
    				250
    			);
    		}

    		if ($$self.$$.dirty & /*info*/ 1) {
    			 $$invalidate(1, cx = info.x);
    		}

    		if ($$self.$$.dirty & /*info*/ 1) {
    			 $$invalidate(2, cy = info.y);
    		}
    	};

    	return [info, cx, cy, onMouseDown];
    }

    class G_bang extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$1, create_fragment$1, safe_not_equal, { info: 0 });

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "G_bang",
    			options,
    			id: create_fragment$1.name
    		});

    		const { ctx } = this.$$;
    		const props = options.props || {};

    		if (/*info*/ ctx[0] === undefined && !("info" in props)) {
    			console.warn("<G_bang> was created without expected prop 'info'");
    		}
    	}

    	get info() {
    		throw new Error("<G_bang>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set info(value) {
    		throw new Error("<G_bang>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/G_number.svelte generated by Svelte v3.21.0 */
    const file$2 = "src/G_number.svelte";

    function create_fragment$2(ctx) {
    	let rect;
    	let rect_x_value;
    	let rect_y_value;
    	let t;
    	let foreignObject;
    	let input;
    	let input_value_value;
    	let foreignObject_x_value;
    	let foreignObject_y_value;
    	let dispose;

    	const block = {
    		c: function create() {
    			rect = svg_element("rect");
    			t = space();
    			foreignObject = svg_element("foreignObject");
    			input = element("input");
    			attr_dev(rect, "x", rect_x_value = /*x*/ ctx[1] - 10);
    			attr_dev(rect, "y", rect_y_value = /*y*/ ctx[2] - 10);
    			attr_dev(rect, "width", "60");
    			attr_dev(rect, "height", "20");
    			attr_dev(rect, "class", "svelte-qxb1ut");
    			add_location(rect, file$2, 29, 0, 739);
    			attr_dev(input, "type", "number");
    			input.value = input_value_value = /*info*/ ctx[0].value;
    			attr_dev(input, "class", "svelte-qxb1ut");
    			add_location(input, file$2, 31, 4, 841);
    			attr_dev(foreignObject, "x", foreignObject_x_value = /*x*/ ctx[1] - 5);
    			attr_dev(foreignObject, "y", foreignObject_y_value = /*y*/ ctx[2] - 9);
    			attr_dev(foreignObject, "width", "54");
    			attr_dev(foreignObject, "height", "18");
    			add_location(foreignObject, file$2, 30, 0, 785);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor, remount) {
    			insert_dev(target, rect, anchor);
    			insert_dev(target, t, anchor);
    			insert_dev(target, foreignObject, anchor);
    			append_dev(foreignObject, input);
    			if (remount) run_all(dispose);

    			dispose = [
    				listen_dev(input, "mousedown", stop_propagation(onMouseDown), false, false, true),
    				listen_dev(input, "keyup", /*keyUp*/ ctx[3], false, false, false),
    				listen_dev(input, "blur", /*onBlur*/ ctx[4], false, false, false)
    			];
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*x*/ 2 && rect_x_value !== (rect_x_value = /*x*/ ctx[1] - 10)) {
    				attr_dev(rect, "x", rect_x_value);
    			}

    			if (dirty & /*y*/ 4 && rect_y_value !== (rect_y_value = /*y*/ ctx[2] - 10)) {
    				attr_dev(rect, "y", rect_y_value);
    			}

    			if (dirty & /*info*/ 1 && input_value_value !== (input_value_value = /*info*/ ctx[0].value)) {
    				prop_dev(input, "value", input_value_value);
    			}

    			if (dirty & /*x*/ 2 && foreignObject_x_value !== (foreignObject_x_value = /*x*/ ctx[1] - 5)) {
    				attr_dev(foreignObject, "x", foreignObject_x_value);
    			}

    			if (dirty & /*y*/ 4 && foreignObject_y_value !== (foreignObject_y_value = /*y*/ ctx[2] - 9)) {
    				attr_dev(foreignObject, "y", foreignObject_y_value);
    			}
    		},
    		i: noop,
    		o: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(rect);
    			if (detaching) detach_dev(t);
    			if (detaching) detach_dev(foreignObject);
    			run_all(dispose);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$2.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function onMouseDown(e) {
    	e.target.focus(); // TODO a hack, but it works reasonably well this way
    }

    function instance$2($$self, $$props, $$invalidate) {
    	const sendMsg = getContext("sendMsg");
    	let { info } = $$props;
    	info.value = +info.cmd.slice(6) || 0;

    	function keyUp(e) {
    		if (e.keyCode === 13) e.target.blur(); else if (e.keyCode === 27) e.srcElement.value = info.value;
    	}

    	function onBlur(e) {
    		// note: don't use bind:value, send to engine first
    		const value = e.srcElement.value;

    		sendMsg(info.id, "d", 0, +value);
    	} // e.target.blur()  // this will stop re-sending on window focus loss

    	const writable_props = ["info"];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<G_number> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("G_number", $$slots, []);

    	$$self.$set = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    	};

    	$$self.$capture_state = () => ({
    		getContext,
    		sendMsg,
    		info,
    		onMouseDown,
    		keyUp,
    		onBlur,
    		x,
    		y
    	});

    	$$self.$inject_state = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    		if ("x" in $$props) $$invalidate(1, x = $$props.x);
    		if ("y" in $$props) $$invalidate(2, y = $$props.y);
    	};

    	let x;
    	let y;

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	$$self.$$.update = () => {
    		if ($$self.$$.dirty & /*info*/ 1) {
    			 $$invalidate(1, x = info.x);
    		}

    		if ($$self.$$.dirty & /*info*/ 1) {
    			 $$invalidate(2, y = info.y);
    		}
    	};

    	return [info, x, y, keyUp, onBlur];
    }

    class G_number extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$2, create_fragment$2, safe_not_equal, { info: 0 });

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "G_number",
    			options,
    			id: create_fragment$2.name
    		});

    		const { ctx } = this.$$;
    		const props = options.props || {};

    		if (/*info*/ ctx[0] === undefined && !("info" in props)) {
    			console.warn("<G_number> was created without expected prop 'info'");
    		}
    	}

    	get info() {
    		throw new Error("<G_number>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set info(value) {
    		throw new Error("<G_number>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/G_slider.svelte generated by Svelte v3.21.0 */
    const file$3 = "src/G_slider.svelte";

    function create_fragment$3(ctx) {
    	let rect;
    	let rect_x_value;
    	let rect_y_value;
    	let t;
    	let foreignObject;
    	let input;
    	let input_value_value;
    	let foreignObject_x_value;
    	let foreignObject_y_value;
    	let dispose;

    	const block = {
    		c: function create() {
    			rect = svg_element("rect");
    			t = space();
    			foreignObject = svg_element("foreignObject");
    			input = element("input");
    			attr_dev(rect, "x", rect_x_value = /*x*/ ctx[1] - 10);
    			attr_dev(rect, "y", rect_y_value = /*y*/ ctx[2] - 10);
    			attr_dev(rect, "width", "110");
    			attr_dev(rect, "height", "30");
    			attr_dev(rect, "class", "svelte-ywyo4i");
    			add_location(rect, file$3, 23, 0, 540);
    			attr_dev(input, "type", "range");
    			attr_dev(input, "min", "0");
    			attr_dev(input, "max", "100");
    			input.value = input_value_value = /*info*/ ctx[0].value;
    			attr_dev(input, "class", "svelte-ywyo4i");
    			add_location(input, file$3, 25, 4, 644);
    			attr_dev(foreignObject, "x", foreignObject_x_value = /*x*/ ctx[1] - 3);
    			attr_dev(foreignObject, "y", foreignObject_y_value = /*y*/ ctx[2] - 9);
    			attr_dev(foreignObject, "width", "104");
    			attr_dev(foreignObject, "height", "28");
    			add_location(foreignObject, file$3, 24, 0, 587);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor, remount) {
    			insert_dev(target, rect, anchor);
    			insert_dev(target, t, anchor);
    			insert_dev(target, foreignObject, anchor);
    			append_dev(foreignObject, input);
    			if (remount) run_all(dispose);

    			dispose = [
    				listen_dev(input, "mousedown", stop_propagation(onMouseDown$1), false, false, true),
    				listen_dev(input, "mouseup", /*onMouseUp*/ ctx[3], false, false, false)
    			];
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*x*/ 2 && rect_x_value !== (rect_x_value = /*x*/ ctx[1] - 10)) {
    				attr_dev(rect, "x", rect_x_value);
    			}

    			if (dirty & /*y*/ 4 && rect_y_value !== (rect_y_value = /*y*/ ctx[2] - 10)) {
    				attr_dev(rect, "y", rect_y_value);
    			}

    			if (dirty & /*info*/ 1 && input_value_value !== (input_value_value = /*info*/ ctx[0].value)) {
    				prop_dev(input, "value", input_value_value);
    			}

    			if (dirty & /*x*/ 2 && foreignObject_x_value !== (foreignObject_x_value = /*x*/ ctx[1] - 3)) {
    				attr_dev(foreignObject, "x", foreignObject_x_value);
    			}

    			if (dirty & /*y*/ 4 && foreignObject_y_value !== (foreignObject_y_value = /*y*/ ctx[2] - 9)) {
    				attr_dev(foreignObject, "y", foreignObject_y_value);
    			}
    		},
    		i: noop,
    		o: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(rect);
    			if (detaching) detach_dev(t);
    			if (detaching) detach_dev(foreignObject);
    			run_all(dispose);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$3.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function onMouseDown$1(e) {
    	e.target.focus(); // TODO a hack, but it works reasonably well this way
    }

    function instance$3($$self, $$props, $$invalidate) {
    	const sendMsg = getContext("sendMsg");
    	let { info } = $$props;
    	info.dyOut = 20;
    	info.value = +info.cmd.slice(6) || 0;

    	function onMouseUp(e) {
    		// note: don't use bind:value, send to engine first
    		const value = e.srcElement.value;

    		sendMsg(info.id, "d", 0, +value);
    		e.target.blur();
    	}

    	const writable_props = ["info"];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<G_slider> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("G_slider", $$slots, []);

    	$$self.$set = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    	};

    	$$self.$capture_state = () => ({
    		getContext,
    		sendMsg,
    		info,
    		onMouseDown: onMouseDown$1,
    		onMouseUp,
    		x,
    		y
    	});

    	$$self.$inject_state = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    		if ("x" in $$props) $$invalidate(1, x = $$props.x);
    		if ("y" in $$props) $$invalidate(2, y = $$props.y);
    	};

    	let x;
    	let y;

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	$$self.$$.update = () => {
    		if ($$self.$$.dirty & /*info*/ 1) {
    			 $$invalidate(1, x = info.x);
    		}

    		if ($$self.$$.dirty & /*info*/ 1) {
    			 $$invalidate(2, y = info.y);
    		}
    	};

    	return [info, x, y, onMouseUp];
    }

    class G_slider extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$3, create_fragment$3, safe_not_equal, { info: 0 });

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "G_slider",
    			options,
    			id: create_fragment$3.name
    		});

    		const { ctx } = this.$$;
    		const props = options.props || {};

    		if (/*info*/ ctx[0] === undefined && !("info" in props)) {
    			console.warn("<G_slider> was created without expected prop 'info'");
    		}
    	}

    	get info() {
    		throw new Error("<G_slider>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set info(value) {
    		throw new Error("<G_slider>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/G_toggle.svelte generated by Svelte v3.21.0 */
    const file$4 = "src/G_toggle.svelte";

    function create_fragment$4(ctx) {
    	let rect;
    	let rect_x_value;
    	let rect_y_value;
    	let t0;
    	let circle;
    	let t1;
    	let line0;
    	let line0_x__value;
    	let line0_y__value;
    	let line0_x__value_1;
    	let line0_y__value_1;
    	let t2;
    	let line1;
    	let line1_x__value;
    	let line1_y__value;
    	let line1_x__value_1;
    	let line1_y__value_1;
    	let dispose;

    	const block = {
    		c: function create() {
    			rect = svg_element("rect");
    			t0 = space();
    			circle = svg_element("circle");
    			t1 = space();
    			line0 = svg_element("line");
    			t2 = space();
    			line1 = svg_element("line");
    			attr_dev(rect, "x", rect_x_value = /*x*/ ctx[0] - 10);
    			attr_dev(rect, "y", rect_y_value = /*y*/ ctx[1] - 10);
    			attr_dev(rect, "width", "20");
    			attr_dev(rect, "height", "20");
    			attr_dev(rect, "class", "svelte-159lfec");
    			add_location(rect, file$4, 14, 0, 258);
    			attr_dev(circle, "cx", /*x*/ ctx[0]);
    			attr_dev(circle, "cy", /*y*/ ctx[1]);
    			attr_dev(circle, "r", "7");
    			attr_dev(circle, "class", "svelte-159lfec");
    			add_location(circle, file$4, 15, 0, 304);
    			attr_dev(line0, "x1", line0_x__value = /*x*/ ctx[0] - 8);
    			attr_dev(line0, "y1", line0_y__value = /*y*/ ctx[1] - 8);
    			attr_dev(line0, "x2", line0_x__value_1 = /*x*/ ctx[0] + 8);
    			attr_dev(line0, "y2", line0_y__value_1 = /*y*/ ctx[1] + 8);
    			attr_dev(line0, "class", "svelte-159lfec");
    			toggle_class(line0, "on", /*on*/ ctx[2]);
    			add_location(line0, file$4, 17, 0, 399);
    			attr_dev(line1, "x1", line1_x__value = /*x*/ ctx[0] + 8);
    			attr_dev(line1, "y1", line1_y__value = /*y*/ ctx[1] - 8);
    			attr_dev(line1, "x2", line1_x__value_1 = /*x*/ ctx[0] - 8);
    			attr_dev(line1, "y2", line1_y__value_1 = /*y*/ ctx[1] + 8);
    			attr_dev(line1, "class", "svelte-159lfec");
    			toggle_class(line1, "on", /*on*/ ctx[2]);
    			add_location(line1, file$4, 18, 0, 453);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor, remount) {
    			insert_dev(target, rect, anchor);
    			insert_dev(target, t0, anchor);
    			insert_dev(target, circle, anchor);
    			insert_dev(target, t1, anchor);
    			insert_dev(target, line0, anchor);
    			insert_dev(target, t2, anchor);
    			insert_dev(target, line1, anchor);
    			if (remount) dispose();
    			dispose = listen_dev(circle, "mousedown", stop_propagation(prevent_default(/*onMouseDown*/ ctx[3])), false, true, true);
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*x*/ 1 && rect_x_value !== (rect_x_value = /*x*/ ctx[0] - 10)) {
    				attr_dev(rect, "x", rect_x_value);
    			}

    			if (dirty & /*y*/ 2 && rect_y_value !== (rect_y_value = /*y*/ ctx[1] - 10)) {
    				attr_dev(rect, "y", rect_y_value);
    			}

    			if (dirty & /*x*/ 1) {
    				attr_dev(circle, "cx", /*x*/ ctx[0]);
    			}

    			if (dirty & /*y*/ 2) {
    				attr_dev(circle, "cy", /*y*/ ctx[1]);
    			}

    			if (dirty & /*x*/ 1 && line0_x__value !== (line0_x__value = /*x*/ ctx[0] - 8)) {
    				attr_dev(line0, "x1", line0_x__value);
    			}

    			if (dirty & /*y*/ 2 && line0_y__value !== (line0_y__value = /*y*/ ctx[1] - 8)) {
    				attr_dev(line0, "y1", line0_y__value);
    			}

    			if (dirty & /*x*/ 1 && line0_x__value_1 !== (line0_x__value_1 = /*x*/ ctx[0] + 8)) {
    				attr_dev(line0, "x2", line0_x__value_1);
    			}

    			if (dirty & /*y*/ 2 && line0_y__value_1 !== (line0_y__value_1 = /*y*/ ctx[1] + 8)) {
    				attr_dev(line0, "y2", line0_y__value_1);
    			}

    			if (dirty & /*on*/ 4) {
    				toggle_class(line0, "on", /*on*/ ctx[2]);
    			}

    			if (dirty & /*x*/ 1 && line1_x__value !== (line1_x__value = /*x*/ ctx[0] + 8)) {
    				attr_dev(line1, "x1", line1_x__value);
    			}

    			if (dirty & /*y*/ 2 && line1_y__value !== (line1_y__value = /*y*/ ctx[1] - 8)) {
    				attr_dev(line1, "y1", line1_y__value);
    			}

    			if (dirty & /*x*/ 1 && line1_x__value_1 !== (line1_x__value_1 = /*x*/ ctx[0] - 8)) {
    				attr_dev(line1, "x2", line1_x__value_1);
    			}

    			if (dirty & /*y*/ 2 && line1_y__value_1 !== (line1_y__value_1 = /*y*/ ctx[1] + 8)) {
    				attr_dev(line1, "y2", line1_y__value_1);
    			}

    			if (dirty & /*on*/ 4) {
    				toggle_class(line1, "on", /*on*/ ctx[2]);
    			}
    		},
    		i: noop,
    		o: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(rect);
    			if (detaching) detach_dev(t0);
    			if (detaching) detach_dev(circle);
    			if (detaching) detach_dev(t1);
    			if (detaching) detach_dev(line0);
    			if (detaching) detach_dev(t2);
    			if (detaching) detach_dev(line1);
    			dispose();
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$4.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function instance$4($$self, $$props, $$invalidate) {
    	const sendMsg = getContext("sendMsg");
    	let { info } = $$props;

    	function onMouseDown(e) {
    		sendMsg(info.id, "d", 0, []);
    	}

    	const writable_props = ["info"];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<G_toggle> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("G_toggle", $$slots, []);

    	$$self.$set = $$props => {
    		if ("info" in $$props) $$invalidate(4, info = $$props.info);
    	};

    	$$self.$capture_state = () => ({
    		getContext,
    		sendMsg,
    		info,
    		onMouseDown,
    		x,
    		y,
    		on
    	});

    	$$self.$inject_state = $$props => {
    		if ("info" in $$props) $$invalidate(4, info = $$props.info);
    		if ("x" in $$props) $$invalidate(0, x = $$props.x);
    		if ("y" in $$props) $$invalidate(1, y = $$props.y);
    		if ("on" in $$props) $$invalidate(2, on = $$props.on);
    	};

    	let x;
    	let y;
    	let on;

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	$$self.$$.update = () => {
    		if ($$self.$$.dirty & /*info*/ 16) {
    			 $$invalidate(0, x = info.x);
    		}

    		if ($$self.$$.dirty & /*info*/ 16) {
    			 $$invalidate(1, y = info.y);
    		}

    		if ($$self.$$.dirty & /*info*/ 16) {
    			 $$invalidate(2, on = info.value);
    		}
    	};

    	return [x, y, on, onMouseDown, info];
    }

    class G_toggle extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$4, create_fragment$4, safe_not_equal, { info: 4 });

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "G_toggle",
    			options,
    			id: create_fragment$4.name
    		});

    		const { ctx } = this.$$;
    		const props = options.props || {};

    		if (/*info*/ ctx[4] === undefined && !("info" in props)) {
    			console.warn("<G_toggle> was created without expected prop 'info'");
    		}
    	}

    	get info() {
    		throw new Error("<G_toggle>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set info(value) {
    		throw new Error("<G_toggle>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/Generic.svelte generated by Svelte v3.21.0 */
    const file$5 = "src/Generic.svelte";

    function create_fragment$5(ctx) {
    	let rect;
    	let rect_y_value;
    	let t0;
    	let text_1;
    	let t1_value = /*info*/ ctx[0].cmd + "";
    	let t1;
    	let text_1_x_value;
    	let text_1_y_value;

    	const block = {
    		c: function create() {
    			rect = svg_element("rect");
    			t0 = space();
    			text_1 = svg_element("text");
    			t1 = text(t1_value);
    			attr_dev(rect, "x", /*x*/ ctx[3]);
    			attr_dev(rect, "y", rect_y_value = /*y*/ ctx[4] - 10);
    			attr_dev(rect, "width", /*width*/ ctx[2]);
    			attr_dev(rect, "height", "20");
    			attr_dev(rect, "rx", "6");
    			attr_dev(rect, "class", "svelte-q5j6ez");
    			add_location(rect, file$5, 28, 0, 628);
    			attr_dev(text_1, "x", text_1_x_value = /*x*/ ctx[3] + 5);
    			attr_dev(text_1, "y", text_1_y_value = /*y*/ ctx[4] + 5);
    			attr_dev(text_1, "class", "svelte-q5j6ez");
    			add_location(text_1, file$5, 29, 0, 675);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, rect, anchor);
    			insert_dev(target, t0, anchor);
    			insert_dev(target, text_1, anchor);
    			append_dev(text_1, t1);
    			/*text_1_binding*/ ctx[7](text_1);
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*x*/ 8) {
    				attr_dev(rect, "x", /*x*/ ctx[3]);
    			}

    			if (dirty & /*y*/ 16 && rect_y_value !== (rect_y_value = /*y*/ ctx[4] - 10)) {
    				attr_dev(rect, "y", rect_y_value);
    			}

    			if (dirty & /*width*/ 4) {
    				attr_dev(rect, "width", /*width*/ ctx[2]);
    			}

    			if (dirty & /*info*/ 1 && t1_value !== (t1_value = /*info*/ ctx[0].cmd + "")) set_data_dev(t1, t1_value);

    			if (dirty & /*x*/ 8 && text_1_x_value !== (text_1_x_value = /*x*/ ctx[3] + 5)) {
    				attr_dev(text_1, "x", text_1_x_value);
    			}

    			if (dirty & /*y*/ 16 && text_1_y_value !== (text_1_y_value = /*y*/ ctx[4] + 5)) {
    				attr_dev(text_1, "y", text_1_y_value);
    			}
    		},
    		i: noop,
    		o: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(rect);
    			if (detaching) detach_dev(t0);
    			if (detaching) detach_dev(text_1);
    			/*text_1_binding*/ ctx[7](null);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$5.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function instance$5($$self, $$props, $$invalidate) {
    	let { info } = $$props;
    	const minWidth = 20 * Math.max(info.i, info.o);
    	let textElt, width = 0;

    	function placeLets(vec) {
    		const num = vec.length;
    		const xstep = (width - 10 * num - 10) / Math.max(1, num - 1) + 10;
    		for (let i = 0; i < num; i++) vec[i] = 10 + i * xstep;
    	}

    	onMount(() => {
    		if (textElt) $$invalidate(2, width = textElt.getBBox().width + 10);
    		if (width < minWidth) $$invalidate(2, width = minWidth);
    		placeLets(info.dxIns);
    		placeLets(info.dxOuts);
    	});

    	const writable_props = ["info"];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<Generic> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("Generic", $$slots, []);

    	function text_1_binding($$value) {
    		binding_callbacks[$$value ? "unshift" : "push"](() => {
    			$$invalidate(1, textElt = $$value);
    		});
    	}

    	$$self.$set = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    	};

    	$$self.$capture_state = () => ({
    		onMount,
    		info,
    		minWidth,
    		textElt,
    		width,
    		placeLets,
    		x,
    		y
    	});

    	$$self.$inject_state = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    		if ("textElt" in $$props) $$invalidate(1, textElt = $$props.textElt);
    		if ("width" in $$props) $$invalidate(2, width = $$props.width);
    		if ("x" in $$props) $$invalidate(3, x = $$props.x);
    		if ("y" in $$props) $$invalidate(4, y = $$props.y);
    	};

    	let x;
    	let y;

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	$$self.$$.update = () => {
    		if ($$self.$$.dirty & /*info*/ 1) {
    			 $$invalidate(3, x = info.x);
    		}

    		if ($$self.$$.dirty & /*info*/ 1) {
    			 $$invalidate(4, y = info.y);
    		}
    	};

    	return [info, textElt, width, x, y, minWidth, placeLets, text_1_binding];
    }

    class Generic extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$5, create_fragment$5, safe_not_equal, { info: 0 });

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "Generic",
    			options,
    			id: create_fragment$5.name
    		});

    		const { ctx } = this.$$;
    		const props = options.props || {};

    		if (/*info*/ ctx[0] === undefined && !("info" in props)) {
    			console.warn("<Generic> was created without expected prop 'info'");
    		}
    	}

    	get info() {
    		throw new Error("<Generic>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set info(value) {
    		throw new Error("<Generic>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/Comment.svelte generated by Svelte v3.21.0 */

    const file$6 = "src/Comment.svelte";

    function create_fragment$6(ctx) {
    	let text_1;
    	let t_value = /*info*/ ctx[0].text + "";
    	let t;
    	let text_1_x_value;
    	let text_1_y_value;

    	const block = {
    		c: function create() {
    			text_1 = svg_element("text");
    			t = text(t_value);
    			attr_dev(text_1, "x", text_1_x_value = /*info*/ ctx[0].x);
    			attr_dev(text_1, "y", text_1_y_value = /*info*/ ctx[0].y);
    			add_location(text_1, file$6, 4, 0, 40);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, text_1, anchor);
    			append_dev(text_1, t);
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*info*/ 1 && t_value !== (t_value = /*info*/ ctx[0].text + "")) set_data_dev(t, t_value);

    			if (dirty & /*info*/ 1 && text_1_x_value !== (text_1_x_value = /*info*/ ctx[0].x)) {
    				attr_dev(text_1, "x", text_1_x_value);
    			}

    			if (dirty & /*info*/ 1 && text_1_y_value !== (text_1_y_value = /*info*/ ctx[0].y)) {
    				attr_dev(text_1, "y", text_1_y_value);
    			}
    		},
    		i: noop,
    		o: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(text_1);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$6.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function instance$6($$self, $$props, $$invalidate) {
    	let { info } = $$props;
    	const writable_props = ["info"];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<Comment> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("Comment", $$slots, []);

    	$$self.$set = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    	};

    	$$self.$capture_state = () => ({ info });

    	$$self.$inject_state = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    	};

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	return [info];
    }

    class Comment extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$6, create_fragment$6, safe_not_equal, { info: 0 });

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "Comment",
    			options,
    			id: create_fragment$6.name
    		});

    		const { ctx } = this.$$;
    		const props = options.props || {};

    		if (/*info*/ ctx[0] === undefined && !("info" in props)) {
    			console.warn("<Comment> was created without expected prop 'info'");
    		}
    	}

    	get info() {
    		throw new Error("<Comment>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set info(value) {
    		throw new Error("<Comment>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/Gadget.svelte generated by Svelte v3.21.0 */
    const file$7 = "src/Gadget.svelte";

    function get_each_context$1(ctx, list, i) {
    	const child_ctx = ctx.slice();
    	child_ctx[5] = list[i];
    	child_ctx[7] = i;
    	return child_ctx;
    }

    function get_each_context_1(ctx, list, i) {
    	const child_ctx = ctx.slice();
    	child_ctx[5] = list[i];
    	child_ctx[7] = i;
    	return child_ctx;
    }

    // (29:4) {#each info.dxIns as dx, i}
    function create_each_block_1(ctx) {
    	let use;
    	let title;
    	let t0;
    	let t1;
    	let use_id_value;
    	let use_x_value;
    	let use_y_value;

    	const block = {
    		c: function create() {
    			use = svg_element("use");
    			title = svg_element("title");
    			t0 = text("inlet #");
    			t1 = text(/*i*/ ctx[7]);
    			add_location(title, file$7, 31, 12, 900);
    			attr_dev(use, "id", use_id_value = "i" + /*i*/ ctx[7]);
    			attr_dev(use, "class", "in svelte-116q6rt");
    			attr_dev(use, "href", "#inlet");
    			attr_dev(use, "x", use_x_value = /*info*/ ctx[0].x + /*dx*/ ctx[5]);
    			attr_dev(use, "y", use_y_value = /*info*/ ctx[0].y + /*info*/ ctx[0].dyIn);
    			add_location(use, file$7, 29, 8, 804);
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, use, anchor);
    			append_dev(use, title);
    			append_dev(title, t0);
    			append_dev(title, t1);
    		},
    		p: function update(ctx, dirty) {
    			if (dirty & /*info*/ 1 && use_x_value !== (use_x_value = /*info*/ ctx[0].x + /*dx*/ ctx[5])) {
    				attr_dev(use, "x", use_x_value);
    			}

    			if (dirty & /*info*/ 1 && use_y_value !== (use_y_value = /*info*/ ctx[0].y + /*info*/ ctx[0].dyIn)) {
    				attr_dev(use, "y", use_y_value);
    			}
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(use);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_each_block_1.name,
    		type: "each",
    		source: "(29:4) {#each info.dxIns as dx, i}",
    		ctx
    	});

    	return block;
    }

    // (35:4) {#each info.dxOuts as dx, i}
    function create_each_block$1(ctx) {
    	let use;
    	let title;
    	let t0;
    	let t1;
    	let use_id_value;
    	let use_x_value;
    	let use_y_value;

    	const block = {
    		c: function create() {
    			use = svg_element("use");
    			title = svg_element("title");
    			t0 = text("outlet #");
    			t1 = text(/*i*/ ctx[7]);
    			add_location(title, file$7, 37, 12, 1093);
    			attr_dev(use, "id", use_id_value = "o" + /*i*/ ctx[7]);
    			attr_dev(use, "class", "out svelte-116q6rt");
    			attr_dev(use, "href", "#outlet");
    			attr_dev(use, "x", use_x_value = /*info*/ ctx[0].x + /*dx*/ ctx[5]);
    			attr_dev(use, "y", use_y_value = /*info*/ ctx[0].y + /*info*/ ctx[0].dyOut);
    			add_location(use, file$7, 35, 8, 994);
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, use, anchor);
    			append_dev(use, title);
    			append_dev(title, t0);
    			append_dev(title, t1);
    		},
    		p: function update(ctx, dirty) {
    			if (dirty & /*info*/ 1 && use_x_value !== (use_x_value = /*info*/ ctx[0].x + /*dx*/ ctx[5])) {
    				attr_dev(use, "x", use_x_value);
    			}

    			if (dirty & /*info*/ 1 && use_y_value !== (use_y_value = /*info*/ ctx[0].y + /*info*/ ctx[0].dyOut)) {
    				attr_dev(use, "y", use_y_value);
    			}
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(use);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_each_block$1.name,
    		type: "each",
    		source: "(35:4) {#each info.dxOuts as dx, i}",
    		ctx
    	});

    	return block;
    }

    function create_fragment$7(ctx) {
    	let g;
    	let updating_info;
    	let switch_instance_anchor;
    	let each0_anchor;
    	let g_id_value;
    	let current;

    	function switch_instance_info_binding(value) {
    		/*switch_instance_info_binding*/ ctx[4].call(null, value);
    	}

    	var switch_value = /*component*/ ctx[1];

    	function switch_props(ctx) {
    		let switch_instance_props = {};

    		if (/*info*/ ctx[0] !== void 0) {
    			switch_instance_props.info = /*info*/ ctx[0];
    		}

    		return {
    			props: switch_instance_props,
    			$$inline: true
    		};
    	}

    	if (switch_value) {
    		var switch_instance = new switch_value(switch_props(ctx));
    		binding_callbacks.push(() => bind(switch_instance, "info", switch_instance_info_binding));
    	}

    	let each_value_1 = /*info*/ ctx[0].dxIns;
    	validate_each_argument(each_value_1);
    	let each_blocks_1 = [];

    	for (let i = 0; i < each_value_1.length; i += 1) {
    		each_blocks_1[i] = create_each_block_1(get_each_context_1(ctx, each_value_1, i));
    	}

    	let each_value = /*info*/ ctx[0].dxOuts;
    	validate_each_argument(each_value);
    	let each_blocks = [];

    	for (let i = 0; i < each_value.length; i += 1) {
    		each_blocks[i] = create_each_block$1(get_each_context$1(ctx, each_value, i));
    	}

    	const block = {
    		c: function create() {
    			g = svg_element("g");
    			if (switch_instance) create_component(switch_instance.$$.fragment);
    			switch_instance_anchor = empty();

    			for (let i = 0; i < each_blocks_1.length; i += 1) {
    				each_blocks_1[i].c();
    			}

    			each0_anchor = empty();

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].c();
    			}

    			attr_dev(g, "id", g_id_value = /*info*/ ctx[0].id);
    			attr_dev(g, "class", "draggable svelte-116q6rt");
    			add_location(g, file$7, 26, 0, 678);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, g, anchor);

    			if (switch_instance) {
    				mount_component(switch_instance, g, null);
    			}

    			append_dev(g, switch_instance_anchor);

    			for (let i = 0; i < each_blocks_1.length; i += 1) {
    				each_blocks_1[i].m(g, null);
    			}

    			append_dev(g, each0_anchor);

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].m(g, null);
    			}

    			current = true;
    		},
    		p: function update(ctx, [dirty]) {
    			const switch_instance_changes = {};

    			if (!updating_info && dirty & /*info*/ 1) {
    				updating_info = true;
    				switch_instance_changes.info = /*info*/ ctx[0];
    				add_flush_callback(() => updating_info = false);
    			}

    			if (switch_value !== (switch_value = /*component*/ ctx[1])) {
    				if (switch_instance) {
    					group_outros();
    					const old_component = switch_instance;

    					transition_out(old_component.$$.fragment, 1, 0, () => {
    						destroy_component(old_component, 1);
    					});

    					check_outros();
    				}

    				if (switch_value) {
    					switch_instance = new switch_value(switch_props(ctx));
    					binding_callbacks.push(() => bind(switch_instance, "info", switch_instance_info_binding));
    					create_component(switch_instance.$$.fragment);
    					transition_in(switch_instance.$$.fragment, 1);
    					mount_component(switch_instance, g, switch_instance_anchor);
    				} else {
    					switch_instance = null;
    				}
    			} else if (switch_value) {
    				switch_instance.$set(switch_instance_changes);
    			}

    			if (dirty & /*info*/ 1) {
    				each_value_1 = /*info*/ ctx[0].dxIns;
    				validate_each_argument(each_value_1);
    				let i;

    				for (i = 0; i < each_value_1.length; i += 1) {
    					const child_ctx = get_each_context_1(ctx, each_value_1, i);

    					if (each_blocks_1[i]) {
    						each_blocks_1[i].p(child_ctx, dirty);
    					} else {
    						each_blocks_1[i] = create_each_block_1(child_ctx);
    						each_blocks_1[i].c();
    						each_blocks_1[i].m(g, each0_anchor);
    					}
    				}

    				for (; i < each_blocks_1.length; i += 1) {
    					each_blocks_1[i].d(1);
    				}

    				each_blocks_1.length = each_value_1.length;
    			}

    			if (dirty & /*info*/ 1) {
    				each_value = /*info*/ ctx[0].dxOuts;
    				validate_each_argument(each_value);
    				let i;

    				for (i = 0; i < each_value.length; i += 1) {
    					const child_ctx = get_each_context$1(ctx, each_value, i);

    					if (each_blocks[i]) {
    						each_blocks[i].p(child_ctx, dirty);
    					} else {
    						each_blocks[i] = create_each_block$1(child_ctx);
    						each_blocks[i].c();
    						each_blocks[i].m(g, null);
    					}
    				}

    				for (; i < each_blocks.length; i += 1) {
    					each_blocks[i].d(1);
    				}

    				each_blocks.length = each_value.length;
    			}

    			if (!current || dirty & /*info*/ 1 && g_id_value !== (g_id_value = /*info*/ ctx[0].id)) {
    				attr_dev(g, "id", g_id_value);
    			}
    		},
    		i: function intro(local) {
    			if (current) return;
    			if (switch_instance) transition_in(switch_instance.$$.fragment, local);
    			current = true;
    		},
    		o: function outro(local) {
    			if (switch_instance) transition_out(switch_instance.$$.fragment, local);
    			current = false;
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(g);
    			if (switch_instance) destroy_component(switch_instance);
    			destroy_each(each_blocks_1, detaching);
    			destroy_each(each_blocks, detaching);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$7.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function instance$7($$self, $$props, $$invalidate) {
    	let { info } = $$props;
    	info.dxIns = Array(info.i).fill(0);
    	info.dyIn = -10;
    	info.dxOuts = Array(info.o).fill(0);
    	info.dyOut = 10;

    	const types = {
    		bang: G_bang,
    		number: G_number,
    		slider: G_slider,
    		toggle: G_toggle,
    		"#": Comment
    	};

    	const name = info.cmd.match(/\S+/);
    	const component = types[name && name[0]] || Generic;
    	const writable_props = ["info"];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<Gadget> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("Gadget", $$slots, []);

    	function switch_instance_info_binding(value) {
    		info = value;
    		$$invalidate(0, info);
    	}

    	$$self.$set = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    	};

    	$$self.$capture_state = () => ({
    		info,
    		G_bang,
    		G_number,
    		G_slider,
    		G_toggle,
    		Generic,
    		Comment,
    		types,
    		name,
    		component
    	});

    	$$self.$inject_state = $$props => {
    		if ("info" in $$props) $$invalidate(0, info = $$props.info);
    	};

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	return [info, component, types, name, switch_instance_info_binding];
    }

    class Gadget extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$7, create_fragment$7, safe_not_equal, { info: 0 });

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "Gadget",
    			options,
    			id: create_fragment$7.name
    		});

    		const { ctx } = this.$$;
    		const props = options.props || {};

    		if (/*info*/ ctx[0] === undefined && !("info" in props)) {
    			console.warn("<Gadget> was created without expected prop 'info'");
    		}
    	}

    	get info() {
    		throw new Error("<Gadget>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set info(value) {
    		throw new Error("<Gadget>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/Wire.svelte generated by Svelte v3.21.0 */

    const file$8 = "src/Wire.svelte";

    function create_fragment$8(ctx) {
    	let path;

    	const block = {
    		c: function create() {
    			path = svg_element("path");
    			attr_dev(path, "d", /*d*/ ctx[0]);
    			attr_dev(path, "class", "svelte-1oc44uz");
    			add_location(path, file$8, 21, 0, 559);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, path, anchor);
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*d*/ 1) {
    				attr_dev(path, "d", /*d*/ ctx[0]);
    			}
    		},
    		i: noop,
    		o: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(path);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$8.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function inletCoord(g, n) {
    	return [g.x + g.dxIns[n], g.y + g.dyIn];
    }

    function outletCoord(g, n) {
    	return [g.x + g.dxOuts[n], g.y + g.dyOut];
    }

    function wirePath(x1, y1, x2, y2) {
    	return `M ${x1},${y1} C ${x1},${y1 + 25} ${x2},${y2 - 25} ${x2},${y2}`;
    }

    function instance$8($$self, $$props, $$invalidate) {
    	let { fg } = $$props, { fo } = $$props, { tg } = $$props, { ti } = $$props;
    	let d;
    	const writable_props = ["fg", "fo", "tg", "ti"];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<Wire> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("Wire", $$slots, []);

    	$$self.$set = $$props => {
    		if ("fg" in $$props) $$invalidate(1, fg = $$props.fg);
    		if ("fo" in $$props) $$invalidate(2, fo = $$props.fo);
    		if ("tg" in $$props) $$invalidate(3, tg = $$props.tg);
    		if ("ti" in $$props) $$invalidate(4, ti = $$props.ti);
    	};

    	$$self.$capture_state = () => ({
    		inletCoord,
    		outletCoord,
    		wirePath,
    		fg,
    		fo,
    		tg,
    		ti,
    		d
    	});

    	$$self.$inject_state = $$props => {
    		if ("fg" in $$props) $$invalidate(1, fg = $$props.fg);
    		if ("fo" in $$props) $$invalidate(2, fo = $$props.fo);
    		if ("tg" in $$props) $$invalidate(3, tg = $$props.tg);
    		if ("ti" in $$props) $$invalidate(4, ti = $$props.ti);
    		if ("d" in $$props) $$invalidate(0, d = $$props.d);
    	};

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	$$self.$$.update = () => {
    		if ($$self.$$.dirty & /*fg, tg, fo, ti*/ 30) {
    			 if (fg.dxOuts && tg.dxIns) $$invalidate(0, d = wirePath(...outletCoord(fg, fo), ...inletCoord(tg, ti))); // FIXME caused by wrong init order?
    		}
    	};

    	return [d, fg, fo, tg, ti];
    }

    class Wire extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$8, create_fragment$8, safe_not_equal, { fg: 1, fo: 2, tg: 3, ti: 4 });

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "Wire",
    			options,
    			id: create_fragment$8.name
    		});

    		const { ctx } = this.$$;
    		const props = options.props || {};

    		if (/*fg*/ ctx[1] === undefined && !("fg" in props)) {
    			console.warn("<Wire> was created without expected prop 'fg'");
    		}

    		if (/*fo*/ ctx[2] === undefined && !("fo" in props)) {
    			console.warn("<Wire> was created without expected prop 'fo'");
    		}

    		if (/*tg*/ ctx[3] === undefined && !("tg" in props)) {
    			console.warn("<Wire> was created without expected prop 'tg'");
    		}

    		if (/*ti*/ ctx[4] === undefined && !("ti" in props)) {
    			console.warn("<Wire> was created without expected prop 'ti'");
    		}
    	}

    	get fg() {
    		throw new Error("<Wire>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set fg(value) {
    		throw new Error("<Wire>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get fo() {
    		throw new Error("<Wire>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set fo(value) {
    		throw new Error("<Wire>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get tg() {
    		throw new Error("<Wire>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set tg(value) {
    		throw new Error("<Wire>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get ti() {
    		throw new Error("<Wire>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set ti(value) {
    		throw new Error("<Wire>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/Editor.svelte generated by Svelte v3.21.0 */

    const { console: console_1 } = globals;
    const file$9 = "src/Editor.svelte";

    function get_each_context$2(ctx, list, i) {
    	const child_ctx = ctx.slice();
    	child_ctx[14] = list[i];
    	child_ctx[16] = i;
    	return child_ctx;
    }

    function get_each_context_1$1(ctx, list, i) {
    	const child_ctx = ctx.slice();
    	child_ctx[17] = list[i];
    	child_ctx[16] = i;
    	return child_ctx;
    }

    function get_each_context_2(ctx, list, i) {
    	const child_ctx = ctx.slice();
    	child_ctx[19] = list[i];
    	return child_ctx;
    }

    function get_each_context_3(ctx, list, i) {
    	const child_ctx = ctx.slice();
    	child_ctx[22] = list[i][0];
    	child_ctx[23] = list[i][1];
    	child_ctx[24] = list[i][2];
    	child_ctx[25] = list[i][3];
    	return child_ctx;
    }

    // (218:4) {#each wires as [f,fo,t,ti] }
    function create_each_block_3(ctx) {
    	let current;

    	const wire = new Wire({
    			props: {
    				fg: /*gadgets*/ ctx[0][/*f*/ ctx[22]],
    				fo: /*fo*/ ctx[23],
    				tg: /*gadgets*/ ctx[0][/*t*/ ctx[24]],
    				ti: /*ti*/ ctx[25]
    			},
    			$$inline: true
    		});

    	const block = {
    		c: function create() {
    			create_component(wire.$$.fragment);
    		},
    		m: function mount(target, anchor) {
    			mount_component(wire, target, anchor);
    			current = true;
    		},
    		p: function update(ctx, dirty) {
    			const wire_changes = {};
    			if (dirty & /*gadgets, wires*/ 3) wire_changes.fg = /*gadgets*/ ctx[0][/*f*/ ctx[22]];
    			if (dirty & /*wires*/ 2) wire_changes.fo = /*fo*/ ctx[23];
    			if (dirty & /*gadgets, wires*/ 3) wire_changes.tg = /*gadgets*/ ctx[0][/*t*/ ctx[24]];
    			if (dirty & /*wires*/ 2) wire_changes.ti = /*ti*/ ctx[25];
    			wire.$set(wire_changes);
    		},
    		i: function intro(local) {
    			if (current) return;
    			transition_in(wire.$$.fragment, local);
    			current = true;
    		},
    		o: function outro(local) {
    			transition_out(wire.$$.fragment, local);
    			current = false;
    		},
    		d: function destroy(detaching) {
    			destroy_component(wire, detaching);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_each_block_3.name,
    		type: "each",
    		source: "(218:4) {#each wires as [f,fo,t,ti] }",
    		ctx
    	});

    	return block;
    }

    // (221:4) {#each gadgets as info (info.id)}
    function create_each_block_2(key_1, ctx) {
    	let first;
    	let current;

    	const gadget = new Gadget({
    			props: { info: /*info*/ ctx[19] },
    			$$inline: true
    		});

    	const block = {
    		key: key_1,
    		first: null,
    		c: function create() {
    			first = empty();
    			create_component(gadget.$$.fragment);
    			this.first = first;
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, first, anchor);
    			mount_component(gadget, target, anchor);
    			current = true;
    		},
    		p: function update(ctx, dirty) {
    			const gadget_changes = {};
    			if (dirty & /*gadgets*/ 1) gadget_changes.info = /*info*/ ctx[19];
    			gadget.$set(gadget_changes);
    		},
    		i: function intro(local) {
    			if (current) return;
    			transition_in(gadget.$$.fragment, local);
    			current = true;
    		},
    		o: function outro(local) {
    			transition_out(gadget.$$.fragment, local);
    			current = false;
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(first);
    			destroy_component(gadget, detaching);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_each_block_2.name,
    		type: "each",
    		source: "(221:4) {#each gadgets as info (info.id)}",
    		ctx
    	});

    	return block;
    }

    // (227:0) {#each gadgets as g, i}
    function create_each_block_1$1(ctx) {
    	let t0;
    	let t1;
    	let t2_value = JSON.stringify(/*g*/ ctx[17]) + "";
    	let t2;
    	let br;

    	const block = {
    		c: function create() {
    			t0 = text(/*i*/ ctx[16]);
    			t1 = text(": ");
    			t2 = text(t2_value);
    			br = element("br");
    			add_location(br, file$9, 227, 28, 7257);
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, t0, anchor);
    			insert_dev(target, t1, anchor);
    			insert_dev(target, t2, anchor);
    			insert_dev(target, br, anchor);
    		},
    		p: function update(ctx, dirty) {
    			if (dirty & /*gadgets*/ 1 && t2_value !== (t2_value = JSON.stringify(/*g*/ ctx[17]) + "")) set_data_dev(t2, t2_value);
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(t0);
    			if (detaching) detach_dev(t1);
    			if (detaching) detach_dev(t2);
    			if (detaching) detach_dev(br);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_each_block_1$1.name,
    		type: "each",
    		source: "(227:0) {#each gadgets as g, i}",
    		ctx
    	});

    	return block;
    }

    // (232:0) {#each wires as w, i}
    function create_each_block$2(ctx) {
    	let t0;
    	let t1;
    	let t2_value = JSON.stringify(/*w*/ ctx[14]) + "";
    	let t2;
    	let br;

    	const block = {
    		c: function create() {
    			t0 = text(/*i*/ ctx[16]);
    			t1 = text(": ");
    			t2 = text(t2_value);
    			br = element("br");
    			add_location(br, file$9, 232, 28, 7337);
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, t0, anchor);
    			insert_dev(target, t1, anchor);
    			insert_dev(target, t2, anchor);
    			insert_dev(target, br, anchor);
    		},
    		p: function update(ctx, dirty) {
    			if (dirty & /*wires*/ 2 && t2_value !== (t2_value = JSON.stringify(/*w*/ ctx[14]) + "")) set_data_dev(t2, t2_value);
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(t0);
    			if (detaching) detach_dev(t1);
    			if (detaching) detach_dev(t2);
    			if (detaching) detach_dev(br);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_each_block$2.name,
    		type: "each",
    		source: "(232:0) {#each wires as w, i}",
    		ctx
    	});

    	return block;
    }

    function create_fragment$9(ctx) {
    	let div;
    	let label;
    	let t0;
    	let input;
    	let t1;
    	let svg_1;
    	let marker;
    	let circle;
    	let defs;
    	let g0;
    	let rect0;
    	let path0;
    	let g1;
    	let rect1;
    	let path1;
    	let each0_anchor;
    	let each_blocks_2 = [];
    	let each1_lookup = new Map();
    	let t2;
    	let h30;
    	let t4;
    	let t5;
    	let h31;
    	let t7;
    	let each3_anchor;
    	let current;
    	let dispose;
    	let each_value_3 = /*wires*/ ctx[1];
    	validate_each_argument(each_value_3);
    	let each_blocks_3 = [];

    	for (let i = 0; i < each_value_3.length; i += 1) {
    		each_blocks_3[i] = create_each_block_3(get_each_context_3(ctx, each_value_3, i));
    	}

    	const out = i => transition_out(each_blocks_3[i], 1, 1, () => {
    		each_blocks_3[i] = null;
    	});

    	let each_value_2 = /*gadgets*/ ctx[0];
    	validate_each_argument(each_value_2);
    	const get_key = ctx => /*info*/ ctx[19].id;
    	validate_each_keys(ctx, each_value_2, get_each_context_2, get_key);

    	for (let i = 0; i < each_value_2.length; i += 1) {
    		let child_ctx = get_each_context_2(ctx, each_value_2, i);
    		let key = get_key(child_ctx);
    		each1_lookup.set(key, each_blocks_2[i] = create_each_block_2(key, child_ctx));
    	}

    	let each_value_1 = /*gadgets*/ ctx[0];
    	validate_each_argument(each_value_1);
    	let each_blocks_1 = [];

    	for (let i = 0; i < each_value_1.length; i += 1) {
    		each_blocks_1[i] = create_each_block_1$1(get_each_context_1$1(ctx, each_value_1, i));
    	}

    	let each_value = /*wires*/ ctx[1];
    	validate_each_argument(each_value);
    	let each_blocks = [];

    	for (let i = 0; i < each_value.length; i += 1) {
    		each_blocks[i] = create_each_block$2(get_each_context$2(ctx, each_value, i));
    	}

    	const block = {
    		c: function create() {
    			div = element("div");
    			label = element("label");
    			t0 = text("Create:\n        ");
    			input = element("input");
    			t1 = space();
    			svg_1 = svg_element("svg");
    			marker = svg_element("marker");
    			circle = svg_element("circle");
    			defs = svg_element("defs");
    			g0 = svg_element("g");
    			rect0 = svg_element("rect");
    			path0 = svg_element("path");
    			g1 = svg_element("g");
    			rect1 = svg_element("rect");
    			path1 = svg_element("path");

    			for (let i = 0; i < each_blocks_3.length; i += 1) {
    				each_blocks_3[i].c();
    			}

    			each0_anchor = empty();

    			for (let i = 0; i < each_blocks_2.length; i += 1) {
    				each_blocks_2[i].c();
    			}

    			t2 = space();
    			h30 = element("h3");
    			h30.textContent = "gadgets";
    			t4 = space();

    			for (let i = 0; i < each_blocks_1.length; i += 1) {
    				each_blocks_1[i].c();
    			}

    			t5 = space();
    			h31 = element("h3");
    			h31.textContent = "wires";
    			t7 = space();

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].c();
    			}

    			each3_anchor = empty();
    			attr_dev(input, "size", "40");
    			attr_dev(input, "placeholder", "gadget args ...");
    			add_location(input, file$9, 192, 8, 6112);
    			add_location(label, file$9, 191, 4, 6089);
    			add_location(div, file$9, 190, 0, 6079);
    			attr_dev(circle, "r", "3");
    			add_location(circle, file$9, 205, 8, 6676);
    			attr_dev(marker, "id", "dot");
    			attr_dev(marker, "overflow", "visible");
    			add_location(marker, file$9, 204, 4, 6635);
    			attr_dev(rect0, "x", "-5");
    			attr_dev(rect0, "y", "-1");
    			attr_dev(rect0, "width", "10");
    			attr_dev(rect0, "height", "2");
    			add_location(rect0, file$9, 209, 12, 6750);
    			attr_dev(path0, "d", "M-10,1 A10,10 0 0 1 10,1");
    			attr_dev(path0, "class", "svelte-1h5f4jq");
    			add_location(path0, file$9, 210, 12, 6799);
    			attr_dev(g0, "id", "inlet");
    			add_location(g0, file$9, 208, 8, 6724);
    			attr_dev(rect1, "x", "-5");
    			attr_dev(rect1, "y", "-1");
    			attr_dev(rect1, "width", "10");
    			attr_dev(rect1, "height", "2");
    			add_location(rect1, file$9, 213, 12, 6885);
    			attr_dev(path1, "d", "M-10,-1 A10,10 0 0 0 10,-1");
    			attr_dev(path1, "class", "svelte-1h5f4jq");
    			add_location(path1, file$9, 214, 12, 6934);
    			attr_dev(g1, "id", "outlet");
    			add_location(g1, file$9, 212, 8, 6858);
    			add_location(defs, file$9, 207, 4, 6709);
    			attr_dev(svg_1, "width", "100%");
    			attr_dev(svg_1, "height", "300");
    			attr_dev(svg_1, "class", "svelte-1h5f4jq");
    			add_location(svg_1, file$9, 196, 0, 6198);
    			add_location(h30, file$9, 225, 0, 7188);
    			add_location(h31, file$9, 230, 0, 7272);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor, remount) {
    			insert_dev(target, div, anchor);
    			append_dev(div, label);
    			append_dev(label, t0);
    			append_dev(label, input);
    			insert_dev(target, t1, anchor);
    			insert_dev(target, svg_1, anchor);
    			append_dev(svg_1, marker);
    			append_dev(marker, circle);
    			append_dev(svg_1, defs);
    			append_dev(defs, g0);
    			append_dev(g0, rect0);
    			append_dev(g0, path0);
    			append_dev(defs, g1);
    			append_dev(g1, rect1);
    			append_dev(g1, path1);

    			for (let i = 0; i < each_blocks_3.length; i += 1) {
    				each_blocks_3[i].m(svg_1, null);
    			}

    			append_dev(svg_1, each0_anchor);

    			for (let i = 0; i < each_blocks_2.length; i += 1) {
    				each_blocks_2[i].m(svg_1, null);
    			}

    			/*svg_1_binding*/ ctx[13](svg_1);
    			insert_dev(target, t2, anchor);
    			insert_dev(target, h30, anchor);
    			insert_dev(target, t4, anchor);

    			for (let i = 0; i < each_blocks_1.length; i += 1) {
    				each_blocks_1[i].m(target, anchor);
    			}

    			insert_dev(target, t5, anchor);
    			insert_dev(target, h31, anchor);
    			insert_dev(target, t7, anchor);

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].m(target, anchor);
    			}

    			insert_dev(target, each3_anchor, anchor);
    			current = true;
    			if (remount) run_all(dispose);

    			dispose = [
    				listen_dev(input, "keyup", /*keyUp*/ ctx[5], false, false, false),
    				listen_dev(svg_1, "mousedown", prevent_default(/*dragStart*/ ctx[3]), false, true, false),
    				listen_dev(svg_1, "mouseup", /*dragEnd*/ ctx[4], false, false, false),
    				listen_dev(svg_1, "mouseleave", /*dragEnd*/ ctx[4], false, false, false),
    				listen_dev(svg_1, "touchstart", prevent_default(/*dragStart*/ ctx[3]), false, true, false),
    				listen_dev(svg_1, "touchend", /*dragEnd*/ ctx[4], false, false, false),
    				listen_dev(svg_1, "touchleave", /*dragEnd*/ ctx[4], false, false, false),
    				listen_dev(svg_1, "touchcancel", /*dragEnd*/ ctx[4], false, false, false)
    			];
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*gadgets, wires*/ 3) {
    				each_value_3 = /*wires*/ ctx[1];
    				validate_each_argument(each_value_3);
    				let i;

    				for (i = 0; i < each_value_3.length; i += 1) {
    					const child_ctx = get_each_context_3(ctx, each_value_3, i);

    					if (each_blocks_3[i]) {
    						each_blocks_3[i].p(child_ctx, dirty);
    						transition_in(each_blocks_3[i], 1);
    					} else {
    						each_blocks_3[i] = create_each_block_3(child_ctx);
    						each_blocks_3[i].c();
    						transition_in(each_blocks_3[i], 1);
    						each_blocks_3[i].m(svg_1, each0_anchor);
    					}
    				}

    				group_outros();

    				for (i = each_value_3.length; i < each_blocks_3.length; i += 1) {
    					out(i);
    				}

    				check_outros();
    			}

    			if (dirty & /*gadgets*/ 1) {
    				const each_value_2 = /*gadgets*/ ctx[0];
    				validate_each_argument(each_value_2);
    				group_outros();
    				validate_each_keys(ctx, each_value_2, get_each_context_2, get_key);
    				each_blocks_2 = update_keyed_each(each_blocks_2, dirty, get_key, 1, ctx, each_value_2, each1_lookup, svg_1, outro_and_destroy_block, create_each_block_2, null, get_each_context_2);
    				check_outros();
    			}

    			if (dirty & /*JSON, gadgets*/ 1) {
    				each_value_1 = /*gadgets*/ ctx[0];
    				validate_each_argument(each_value_1);
    				let i;

    				for (i = 0; i < each_value_1.length; i += 1) {
    					const child_ctx = get_each_context_1$1(ctx, each_value_1, i);

    					if (each_blocks_1[i]) {
    						each_blocks_1[i].p(child_ctx, dirty);
    					} else {
    						each_blocks_1[i] = create_each_block_1$1(child_ctx);
    						each_blocks_1[i].c();
    						each_blocks_1[i].m(t5.parentNode, t5);
    					}
    				}

    				for (; i < each_blocks_1.length; i += 1) {
    					each_blocks_1[i].d(1);
    				}

    				each_blocks_1.length = each_value_1.length;
    			}

    			if (dirty & /*JSON, wires*/ 2) {
    				each_value = /*wires*/ ctx[1];
    				validate_each_argument(each_value);
    				let i;

    				for (i = 0; i < each_value.length; i += 1) {
    					const child_ctx = get_each_context$2(ctx, each_value, i);

    					if (each_blocks[i]) {
    						each_blocks[i].p(child_ctx, dirty);
    					} else {
    						each_blocks[i] = create_each_block$2(child_ctx);
    						each_blocks[i].c();
    						each_blocks[i].m(each3_anchor.parentNode, each3_anchor);
    					}
    				}

    				for (; i < each_blocks.length; i += 1) {
    					each_blocks[i].d(1);
    				}

    				each_blocks.length = each_value.length;
    			}
    		},
    		i: function intro(local) {
    			if (current) return;

    			for (let i = 0; i < each_value_3.length; i += 1) {
    				transition_in(each_blocks_3[i]);
    			}

    			for (let i = 0; i < each_value_2.length; i += 1) {
    				transition_in(each_blocks_2[i]);
    			}

    			current = true;
    		},
    		o: function outro(local) {
    			each_blocks_3 = each_blocks_3.filter(Boolean);

    			for (let i = 0; i < each_blocks_3.length; i += 1) {
    				transition_out(each_blocks_3[i]);
    			}

    			for (let i = 0; i < each_blocks_2.length; i += 1) {
    				transition_out(each_blocks_2[i]);
    			}

    			current = false;
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(div);
    			if (detaching) detach_dev(t1);
    			if (detaching) detach_dev(svg_1);
    			destroy_each(each_blocks_3, detaching);

    			for (let i = 0; i < each_blocks_2.length; i += 1) {
    				each_blocks_2[i].d();
    			}

    			/*svg_1_binding*/ ctx[13](null);
    			if (detaching) detach_dev(t2);
    			if (detaching) detach_dev(h30);
    			if (detaching) detach_dev(t4);
    			destroy_each(each_blocks_1, detaching);
    			if (detaching) detach_dev(t5);
    			if (detaching) detach_dev(h31);
    			if (detaching) detach_dev(t7);
    			destroy_each(each_blocks, detaching);
    			if (detaching) detach_dev(each3_anchor);
    			run_all(dispose);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$9.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function newSvgElt(type) {
    	var e = document.createElementNS("http://www.w3.org/2000/svg", type);
    	e.get = k => +e.getAttributeNS(null, k);
    	e.set = (k, v) => e.setAttributeNS(null, k, v);
    	return e;
    }

    function newWire(g, n) {
    	var w = newSvgElt("path");
    	w.set("class", "dragwire");
    	w.gadget = g;
    	w.outlet = n;
    	w.adjustPath = evt => w.set("d", wirePath(...outletCoord(g, n), evt.offsetX, evt.offsetY));
    	return w;
    }

    function newMarquee(evt) {
    	var m = newSvgElt("rect");
    	m.set("class", "marquee");
    	m.set("x", evt.offsetX);
    	m.set("y", evt.offsetY);
    	m.set("width", 0);
    	m.set("height", 0);

    	m.adjustRect = (dx, dy) => {
    		// TODO don't use dx/dy, try to switch to offsetX/Y
    		// FIXME this fails with negative widths or heights
    		m.set("width", m.get("width") + dx);

    		m.set("height", m.get("height") + dy);
    	};

    	return m;
    }

    function getMousePos(evt) {
    	if (evt.touches) evt = evt.touches[0];
    	return { x: evt.clientX, y: evt.clientY };
    }

    function instance$9($$self, $$props, $$invalidate) {
    	const sendMsg = getContext("sendMsg");
    	let gadgets = [];
    	let wires = [];
    	let selection = new Set(), position = { x: 0, y: 0 }, svg, marquee, dragWire;

    	function dragStart(evt) {
    		position = getMousePos(evt);
    		svg.addEventListener("mousemove", dragMove);
    		svg.addEventListener("touchmove", dragMove);
    		const gElt = evt.target.parentElement;

    		if (gElt.classList.contains("draggable")) {
    			const id = +gElt.id;

    			if (evt.target.nodeName == "use" && evt.target.id[0] == "o") {
    				const outlet = +evt.target.id.slice(1);
    				dragWire = newWire(gadgets[id], outlet);
    				svg.appendChild(dragWire);
    			} else {
    				selection.add(id);
    				gElt.parentElement.lastElementChild.after(gElt); // to front
    			}
    		} else {
    			if (!evt.shiftKey) selection.clear();
    			marquee = newMarquee(evt);
    			svg.appendChild(marquee);
    		}
    	}

    	function dragMove(evt) {
    		const { x, y } = getMousePos(evt);
    		const dx = x - position.x;
    		const dy = y - position.y;
    		position.x = x;
    		position.y = y;

    		if (dragWire) dragWire.adjustPath(evt); else if (marquee) marquee.adjustRect(dx, dy); else selection.forEach(id => {
    			$$invalidate(0, gadgets[id].x += dx, gadgets);
    			$$invalidate(0, gadgets[id].y += dy, gadgets);
    		});
    	}

    	function dragEnd(evt) {
    		svg.removeEventListener("mousemove", dragMove);
    		svg.removeEventListener("touchmove", dragMove);

    		if (dragWire) {
    			const { x, y } = getMousePos(evt);
    			const target = document.elementFromPoint(x, y);

    			if (target.nodeName == "use" && target.id[0] == "i") {
    				const gElt = target.parentElement;
    				const inlet = +target.id.slice(1);
    				const d = dragWire;
    				sendMsg(d.gadget.id, "w", d.outlet, +gElt.id, inlet);
    			}

    			svg.removeChild(dragWire);
    			dragWire = null;
    		} else if (marquee) {
    			let m = marquee.getBBox();

    			// TODO tedious: svg.getIntersectionList not available in Firefox
    			for (let elt of document.getElementsByClassName("draggable")) {
    				let e = elt.getBBox();
    				let disjunct = e.x > m.x + m.width || e.x + e.width < m.x || e.y > m.y + m.height || e.y + e.height < m.y;

    				// TODO grrr, not in Firefox: if (svg.checkIntersection(elt, m))
    				if (!disjunct) selection.add(+elt.id);
    			}

    			svg.removeChild(marquee);
    			marquee = null;
    		} else {
    			selection.forEach(id => {
    				const { x, y } = gadgets[id];
    				sendMsg(id, "u", { x, y });
    			});

    			selection.clear();
    		}
    	}

    	function onReceive(msg) {
    		if (msg) {
    			// TODO nesting
    			if (msg[1] == "B") $$invalidate(0, gadgets[msg[0]].value = [], gadgets); else if (msg[1] == "V") $$invalidate(0, gadgets[msg[0]].value = msg[2], gadgets); else if (msg[1] == "P") console.log(msg[2].join(" "), msg[3]); else if (msg[1] == "W") {
    				const w = msg.slice(0, 1).concat(msg.slice(2));
    				const s = w.toString(); // TODO yuck, can't compare as arrays
    				if (wires.some(v => v.toString() == s)) console.log("dup", s); else $$invalidate(1, wires = [...wires, w]);
    			} else if (msg[0] == "G") {
    				if (msg[1] == gadgets.length) {
    					const g = msg[3];
    					g.cmd = msg[2];
    					g.id = msg[1];
    					if (!g.x) g.x = 250;
    					if (!g.y) g.y = 150;
    					$$invalidate(0, gadgets = [...gadgets, g]);
    				} else console.log("dup", msg);
    			} else console.log("ws?", msg);
    		}
    	}

    	function keyUp(e) {
    		if (e.keyCode === 13) {
    			let cmd = e.srcElement.value.trim();
    			e.srcElement.value = "";

    			if (cmd != "") {
    				// a single number creates a number gadget
    				if (!isNaN(+cmd)) cmd = "number " + cmd;

    				const props = {};

    				if (cmd[0] == "#") {
    					props.text = cmd.slice(1).trim();
    					cmd = "#";
    				}

    				sendMsg("g", cmd, props);
    			}
    		}
    	}

    	const writable_props = [];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console_1.warn(`<Editor> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("Editor", $$slots, []);

    	function svg_1_binding($$value) {
    		binding_callbacks[$$value ? "unshift" : "push"](() => {
    			$$invalidate(2, svg = $$value);
    		});
    	}

    	$$self.$capture_state = () => ({
    		getContext,
    		sendMsg,
    		Gadget,
    		Wire,
    		outletCoord,
    		wirePath,
    		gadgets,
    		wires,
    		selection,
    		position,
    		svg,
    		marquee,
    		dragWire,
    		dragStart,
    		dragMove,
    		dragEnd,
    		newSvgElt,
    		newWire,
    		newMarquee,
    		getMousePos,
    		onReceive,
    		keyUp
    	});

    	$$self.$inject_state = $$props => {
    		if ("gadgets" in $$props) $$invalidate(0, gadgets = $$props.gadgets);
    		if ("wires" in $$props) $$invalidate(1, wires = $$props.wires);
    		if ("selection" in $$props) selection = $$props.selection;
    		if ("position" in $$props) position = $$props.position;
    		if ("svg" in $$props) $$invalidate(2, svg = $$props.svg);
    		if ("marquee" in $$props) marquee = $$props.marquee;
    		if ("dragWire" in $$props) dragWire = $$props.dragWire;
    	};

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	return [
    		gadgets,
    		wires,
    		svg,
    		dragStart,
    		dragEnd,
    		keyUp,
    		onReceive,
    		position,
    		marquee,
    		dragWire,
    		sendMsg,
    		selection,
    		dragMove,
    		svg_1_binding
    	];
    }

    class Editor extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$9, create_fragment$9, safe_not_equal, { onReceive: 6 });

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "Editor",
    			options,
    			id: create_fragment$9.name
    		});
    	}

    	get onReceive() {
    		return this.$$.ctx[6];
    	}

    	set onReceive(value) {
    		throw new Error("<Editor>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/Console.svelte generated by Svelte v3.21.0 */

    const { console: console_1$1 } = globals;
    const file$a = "src/Console.svelte";

    // (79:4) {:else}
    function create_else_block(ctx) {
    	let label0;
    	let t0;
    	let input0;
    	let t1;
    	let label1;
    	let t2;
    	let input1;
    	let t3;
    	let button;
    	let dispose;

    	const block = {
    		c: function create() {
    			label0 = element("label");
    			t0 = text("WebREPL address:\n            ");
    			input0 = element("input");
    			t1 = space();
    			label1 = element("label");
    			t2 = text("Port:\n            ");
    			input1 = element("input");
    			t3 = space();
    			button = element("button");
    			button.textContent = "Connect";
    			attr_dev(input0, "type", "text");
    			attr_dev(input0, "size", "17");
    			attr_dev(input0, "class", "svelte-f3loyq");
    			add_location(input0, file$a, 80, 12, 2229);
    			add_location(label0, file$a, 79, 8, 2193);
    			attr_dev(input1, "type", "text");
    			attr_dev(input1, "size", "6");
    			attr_dev(input1, "class", "svelte-f3loyq");
    			add_location(input1, file$a, 83, 12, 2325);
    			add_location(label1, file$a, 82, 8, 2300);
    			add_location(button, file$a, 85, 8, 2395);
    		},
    		m: function mount(target, anchor, remount) {
    			insert_dev(target, label0, anchor);
    			append_dev(label0, t0);
    			append_dev(label0, input0);
    			set_input_value(input0, /*addr*/ ctx[5]);
    			insert_dev(target, t1, anchor);
    			insert_dev(target, label1, anchor);
    			append_dev(label1, t2);
    			append_dev(label1, input1);
    			set_input_value(input1, /*port*/ ctx[6]);
    			insert_dev(target, t3, anchor);
    			insert_dev(target, button, anchor);
    			if (remount) run_all(dispose);

    			dispose = [
    				listen_dev(input0, "input", /*input0_input_handler*/ ctx[13]),
    				listen_dev(input1, "input", /*input1_input_handler*/ ctx[14]),
    				listen_dev(button, "click", /*connect*/ ctx[7], false, false, false)
    			];
    		},
    		p: function update(ctx, dirty) {
    			if (dirty & /*addr*/ 32 && input0.value !== /*addr*/ ctx[5]) {
    				set_input_value(input0, /*addr*/ ctx[5]);
    			}

    			if (dirty & /*port*/ 64 && input1.value !== /*port*/ ctx[6]) {
    				set_input_value(input1, /*port*/ ctx[6]);
    			}
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(label0);
    			if (detaching) detach_dev(t1);
    			if (detaching) detach_dev(label1);
    			if (detaching) detach_dev(t3);
    			if (detaching) detach_dev(button);
    			run_all(dispose);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_else_block.name,
    		type: "else",
    		source: "(79:4) {:else}",
    		ctx
    	});

    	return block;
    }

    // (76:4) {#if ws}
    function create_if_block(ctx) {
    	let input;
    	let input_size_value;
    	let dispose;

    	const block = {
    		c: function create() {
    			input = element("input");
    			attr_dev(input, "type", "text");
    			attr_dev(input, "size", input_size_value = cols + 1);
    			attr_dev(input, "class", "svelte-f3loyq");
    			add_location(input, file$a, 76, 8, 2063);
    		},
    		m: function mount(target, anchor, remount) {
    			insert_dev(target, input, anchor);
    			set_input_value(input, /*cmd*/ ctx[4]);
    			/*input_binding*/ ctx[12](input);
    			if (remount) run_all(dispose);

    			dispose = [
    				listen_dev(input, "input", /*input_input_handler*/ ctx[11]),
    				listen_dev(input, "keydown", /*enterCmd*/ ctx[8], false, false, false)
    			];
    		},
    		p: function update(ctx, dirty) {
    			if (dirty & /*cmd*/ 16 && input.value !== /*cmd*/ ctx[4]) {
    				set_input_value(input, /*cmd*/ ctx[4]);
    			}
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(input);
    			/*input_binding*/ ctx[12](null);
    			run_all(dispose);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_if_block.name,
    		type: "if",
    		source: "(76:4) {#if ws}",
    		ctx
    	});

    	return block;
    }

    function create_fragment$a(ctx) {
    	let textarea_1;
    	let t;
    	let div;

    	function select_block_type(ctx, dirty) {
    		if (/*ws*/ ctx[3]) return create_if_block;
    		return create_else_block;
    	}

    	let current_block_type = select_block_type(ctx);
    	let if_block = current_block_type(ctx);

    	const block = {
    		c: function create() {
    			textarea_1 = element("textarea");
    			t = space();
    			div = element("div");
    			if_block.c();
    			attr_dev(textarea_1, "rows", rows);
    			attr_dev(textarea_1, "cols", cols);
    			textarea_1.disabled = true;
    			textarea_1.value = /*content*/ ctx[2];
    			attr_dev(textarea_1, "class", "svelte-f3loyq");
    			add_location(textarea_1, file$a, 73, 0, 1960);
    			add_location(div, file$a, 74, 0, 2036);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, textarea_1, anchor);
    			/*textarea_1_binding*/ ctx[10](textarea_1);
    			insert_dev(target, t, anchor);
    			insert_dev(target, div, anchor);
    			if_block.m(div, null);
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*content*/ 4) {
    				prop_dev(textarea_1, "value", /*content*/ ctx[2]);
    			}

    			if (current_block_type === (current_block_type = select_block_type(ctx)) && if_block) {
    				if_block.p(ctx, dirty);
    			} else {
    				if_block.d(1);
    				if_block = current_block_type(ctx);

    				if (if_block) {
    					if_block.c();
    					if_block.m(div, null);
    				}
    			}
    		},
    		i: noop,
    		o: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(textarea_1);
    			/*textarea_1_binding*/ ctx[10](null);
    			if (detaching) detach_dev(t);
    			if (detaching) detach_dev(div);
    			if_block.d();
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$a.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    const rows = 25, cols = 80;

    function instance$a($$self, $$props, $$invalidate) {
    	let inputElt, textarea, content = "";

    	function addText(s) {
    		let lines = (content + s).split("\n");
    		if (lines.length > 100) lines = lines.slice(lines.length - 100);
    		$$invalidate(2, content = lines.join("\n"));
    	}

    	afterUpdate(() => {
    		$$invalidate(1, textarea.scrollTop = textarea.scrollHeight, textarea);
    	});

    	let ws = null, cmd = "help()", addr = "192.168.42.20", port = 8266;

    	function connect(e) {
    		let proto = window.location.protocol.replace("http", "ws");
    		let url = `${proto}/${addr}:${port}/`;
    		$$invalidate(3, ws = new WebSocket(url));
    		$$invalidate(3, ws.binaryType = "arraybuffer", ws);

    		//console.log('ws', ws)
    		$$invalidate(
    			3,
    			ws.onopen = () => {
    				inputElt.focus();
    				addText(`\n<<< Connected to ${addr} >>>\n`);
    			},
    			ws
    		);

    		$$invalidate(
    			3,
    			ws.onmessage = e => {
    				if (e.data instanceof ArrayBuffer) {
    					let data = new Uint8Array(e.data);
    					console.log("bin-data", data);
    				} else addText(e.data);
    			},
    			ws
    		);

    		$$invalidate(
    			3,
    			ws.onclose = () => {
    				$$invalidate(3, ws = null);
    				addText("\n<<< Disconnected >>>");
    			},
    			ws
    		);

    		$$invalidate(
    			3,
    			ws.onerror = e => {
    				alert(`Websocket error for ${url}`);
    			},
    			ws
    		);
    	}

    	function enterCmd(e) {
    		//console.log('keyCode', e.keyCode, e)
    		if (e.ctrlKey) switch (e.key) {
    			case "a":
    				ws.send("\u0001");
    				break;
    			case "b":
    				ws.send("\u0002");
    				break;
    			case "c":
    				ws.send("\u0003");
    				break;
    			case "d":
    				ws.send("\u0004");
    				break;
    			case "e":
    				ws.send("\u0005");
    				break;
    		} else if (e.key === "Enter") {
    			ws.send(cmd + "\r"); // raw repl
    			// normal repl
    			// interrupt
    			// soft reset
    			// paste mode

    			$$invalidate(4, cmd = "");
    			return false;
    		}
    	}

    	onDestroy(() => {
    		if (ws) ws.close();
    	});

    	const writable_props = [];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console_1$1.warn(`<Console> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("Console", $$slots, []);

    	function textarea_1_binding($$value) {
    		binding_callbacks[$$value ? "unshift" : "push"](() => {
    			$$invalidate(1, textarea = $$value);
    		});
    	}

    	function input_input_handler() {
    		cmd = this.value;
    		$$invalidate(4, cmd);
    	}

    	function input_binding($$value) {
    		binding_callbacks[$$value ? "unshift" : "push"](() => {
    			$$invalidate(0, inputElt = $$value);
    		});
    	}

    	function input0_input_handler() {
    		addr = this.value;
    		$$invalidate(5, addr);
    	}

    	function input1_input_handler() {
    		port = this.value;
    		$$invalidate(6, port);
    	}

    	$$self.$capture_state = () => ({
    		afterUpdate,
    		onDestroy,
    		rows,
    		cols,
    		inputElt,
    		textarea,
    		content,
    		addText,
    		ws,
    		cmd,
    		addr,
    		port,
    		connect,
    		enterCmd
    	});

    	$$self.$inject_state = $$props => {
    		if ("inputElt" in $$props) $$invalidate(0, inputElt = $$props.inputElt);
    		if ("textarea" in $$props) $$invalidate(1, textarea = $$props.textarea);
    		if ("content" in $$props) $$invalidate(2, content = $$props.content);
    		if ("ws" in $$props) $$invalidate(3, ws = $$props.ws);
    		if ("cmd" in $$props) $$invalidate(4, cmd = $$props.cmd);
    		if ("addr" in $$props) $$invalidate(5, addr = $$props.addr);
    		if ("port" in $$props) $$invalidate(6, port = $$props.port);
    	};

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	return [
    		inputElt,
    		textarea,
    		content,
    		ws,
    		cmd,
    		addr,
    		port,
    		connect,
    		enterCmd,
    		addText,
    		textarea_1_binding,
    		input_input_handler,
    		input_binding,
    		input0_input_handler,
    		input1_input_handler
    	];
    }

    class Console extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$a, create_fragment$a, safe_not_equal, {});

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "Console",
    			options,
    			id: create_fragment$a.name
    		});
    	}
    }

    /* src/Admin.svelte generated by Svelte v3.21.0 */

    function create_fragment$b(ctx) {
    	const block = {
    		c: noop,
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: noop,
    		p: noop,
    		i: noop,
    		o: noop,
    		d: noop
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$b.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function instance$b($$self, $$props) {
    	const writable_props = [];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<Admin> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("Admin", $$slots, []);
    	return [];
    }

    class Admin extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$b, create_fragment$b, safe_not_equal, {});

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "Admin",
    			options,
    			id: create_fragment$b.name
    		});
    	}
    }

    /* src/Tabs.svelte generated by Svelte v3.21.0 */
    const file$b = "src/Tabs.svelte";

    function get_each_context$3(ctx, list, i) {
    	const child_ctx = ctx.slice();
    	child_ctx[4] = list[i];
    	child_ctx[6] = i;
    	return child_ctx;
    }

    // (9:4) {#each names as name, i}
    function create_each_block$3(ctx) {
    	let button;
    	let div;
    	let t0_value = /*name*/ ctx[4] + "";
    	let t0;
    	let t1;
    	let dispose;

    	function click_handler(...args) {
    		return /*click_handler*/ ctx[3](/*i*/ ctx[6], ...args);
    	}

    	const block = {
    		c: function create() {
    			button = element("button");
    			div = element("div");
    			t0 = text(t0_value);
    			t1 = space();
    			attr_dev(div, "class", "svelte-cx0u3t");
    			toggle_class(div, "active", /*i*/ ctx[6] == /*tabNum*/ ctx[1]);
    			add_location(div, file$b, 10, 12, 260);
    			attr_dev(button, "class", "svelte-cx0u3t");
    			add_location(button, file$b, 9, 8, 197);
    		},
    		m: function mount(target, anchor, remount) {
    			insert_dev(target, button, anchor);
    			append_dev(button, div);
    			append_dev(div, t0);
    			append_dev(button, t1);
    			if (remount) dispose();
    			dispose = listen_dev(button, "click", click_handler, false, false, false);
    		},
    		p: function update(new_ctx, dirty) {
    			ctx = new_ctx;
    			if (dirty & /*names*/ 1 && t0_value !== (t0_value = /*name*/ ctx[4] + "")) set_data_dev(t0, t0_value);

    			if (dirty & /*tabNum*/ 2) {
    				toggle_class(div, "active", /*i*/ ctx[6] == /*tabNum*/ ctx[1]);
    			}
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(button);
    			dispose();
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_each_block$3.name,
    		type: "each",
    		source: "(9:4) {#each names as name, i}",
    		ctx
    	});

    	return block;
    }

    function create_fragment$c(ctx) {
    	let div;
    	let each_value = /*names*/ ctx[0];
    	validate_each_argument(each_value);
    	let each_blocks = [];

    	for (let i = 0; i < each_value.length; i += 1) {
    		each_blocks[i] = create_each_block$3(get_each_context$3(ctx, each_value, i));
    	}

    	const block = {
    		c: function create() {
    			div = element("div");

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].c();
    			}

    			attr_dev(div, "class", "tabs svelte-cx0u3t");
    			add_location(div, file$b, 7, 0, 141);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, div, anchor);

    			for (let i = 0; i < each_blocks.length; i += 1) {
    				each_blocks[i].m(div, null);
    			}
    		},
    		p: function update(ctx, [dirty]) {
    			if (dirty & /*dispatch, tabNum, names*/ 7) {
    				each_value = /*names*/ ctx[0];
    				validate_each_argument(each_value);
    				let i;

    				for (i = 0; i < each_value.length; i += 1) {
    					const child_ctx = get_each_context$3(ctx, each_value, i);

    					if (each_blocks[i]) {
    						each_blocks[i].p(child_ctx, dirty);
    					} else {
    						each_blocks[i] = create_each_block$3(child_ctx);
    						each_blocks[i].c();
    						each_blocks[i].m(div, null);
    					}
    				}

    				for (; i < each_blocks.length; i += 1) {
    					each_blocks[i].d(1);
    				}

    				each_blocks.length = each_value.length;
    			}
    		},
    		i: noop,
    		o: noop,
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(div);
    			destroy_each(each_blocks, detaching);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$c.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function instance$c($$self, $$props, $$invalidate) {
    	let { names } = $$props, { tabNum } = $$props;
    	let dispatch = createEventDispatcher();
    	const writable_props = ["names", "tabNum"];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console.warn(`<Tabs> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("Tabs", $$slots, []);
    	const click_handler = i => dispatch("tabChange", i);

    	$$self.$set = $$props => {
    		if ("names" in $$props) $$invalidate(0, names = $$props.names);
    		if ("tabNum" in $$props) $$invalidate(1, tabNum = $$props.tabNum);
    	};

    	$$self.$capture_state = () => ({
    		names,
    		tabNum,
    		createEventDispatcher,
    		dispatch
    	});

    	$$self.$inject_state = $$props => {
    		if ("names" in $$props) $$invalidate(0, names = $$props.names);
    		if ("tabNum" in $$props) $$invalidate(1, tabNum = $$props.tabNum);
    		if ("dispatch" in $$props) $$invalidate(2, dispatch = $$props.dispatch);
    	};

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	return [names, tabNum, dispatch, click_handler];
    }

    class Tabs extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$c, create_fragment$c, safe_not_equal, { names: 0, tabNum: 1 });

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "Tabs",
    			options,
    			id: create_fragment$c.name
    		});

    		const { ctx } = this.$$;
    		const props = options.props || {};

    		if (/*names*/ ctx[0] === undefined && !("names" in props)) {
    			console.warn("<Tabs> was created without expected prop 'names'");
    		}

    		if (/*tabNum*/ ctx[1] === undefined && !("tabNum" in props)) {
    			console.warn("<Tabs> was created without expected prop 'tabNum'");
    		}
    	}

    	get names() {
    		throw new Error("<Tabs>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set names(value) {
    		throw new Error("<Tabs>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	get tabNum() {
    		throw new Error("<Tabs>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set tabNum(value) {
    		throw new Error("<Tabs>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src/App.svelte generated by Svelte v3.21.0 */

    const { console: console_2 } = globals;
    const file$c = "src/App.svelte";

    // (56:23) 
    function create_if_block_3(ctx) {
    	let current;
    	const admin = new Admin({ $$inline: true });

    	const block = {
    		c: function create() {
    			create_component(admin.$$.fragment);
    		},
    		m: function mount(target, anchor) {
    			mount_component(admin, target, anchor);
    			current = true;
    		},
    		p: noop,
    		i: function intro(local) {
    			if (current) return;
    			transition_in(admin.$$.fragment, local);
    			current = true;
    		},
    		o: function outro(local) {
    			transition_out(admin.$$.fragment, local);
    			current = false;
    		},
    		d: function destroy(detaching) {
    			destroy_component(admin, detaching);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_if_block_3.name,
    		type: "if",
    		source: "(56:23) ",
    		ctx
    	});

    	return block;
    }

    // (54:23) 
    function create_if_block_2(ctx) {
    	let current;
    	const console_1 = new Console({ $$inline: true });

    	const block = {
    		c: function create() {
    			create_component(console_1.$$.fragment);
    		},
    		m: function mount(target, anchor) {
    			mount_component(console_1, target, anchor);
    			current = true;
    		},
    		p: noop,
    		i: function intro(local) {
    			if (current) return;
    			transition_in(console_1.$$.fragment, local);
    			current = true;
    		},
    		o: function outro(local) {
    			transition_out(console_1.$$.fragment, local);
    			current = false;
    		},
    		d: function destroy(detaching) {
    			destroy_component(console_1, detaching);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_if_block_2.name,
    		type: "if",
    		source: "(54:23) ",
    		ctx
    	});

    	return block;
    }

    // (52:23) 
    function create_if_block_1(ctx) {
    	let updating_onReceive;
    	let current;

    	function editor_onReceive_binding(value) {
    		/*editor_onReceive_binding*/ ctx[6].call(null, value);
    	}

    	let editor_props = {};

    	if (/*onReceive*/ ctx[0] !== void 0) {
    		editor_props.onReceive = /*onReceive*/ ctx[0];
    	}

    	const editor = new Editor({ props: editor_props, $$inline: true });
    	binding_callbacks.push(() => bind(editor, "onReceive", editor_onReceive_binding));

    	const block = {
    		c: function create() {
    			create_component(editor.$$.fragment);
    		},
    		m: function mount(target, anchor) {
    			mount_component(editor, target, anchor);
    			current = true;
    		},
    		p: function update(ctx, dirty) {
    			const editor_changes = {};

    			if (!updating_onReceive && dirty & /*onReceive*/ 1) {
    				updating_onReceive = true;
    				editor_changes.onReceive = /*onReceive*/ ctx[0];
    				add_flush_callback(() => updating_onReceive = false);
    			}

    			editor.$set(editor_changes);
    		},
    		i: function intro(local) {
    			if (current) return;
    			transition_in(editor.$$.fragment, local);
    			current = true;
    		},
    		o: function outro(local) {
    			transition_out(editor.$$.fragment, local);
    			current = false;
    		},
    		d: function destroy(detaching) {
    			destroy_component(editor, detaching);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_if_block_1.name,
    		type: "if",
    		source: "(52:23) ",
    		ctx
    	});

    	return block;
    }

    // (50:0) {#if tabNum === 0}
    function create_if_block$1(ctx) {
    	let current;
    	const dashboard = new Dashboard({ $$inline: true });

    	const block = {
    		c: function create() {
    			create_component(dashboard.$$.fragment);
    		},
    		m: function mount(target, anchor) {
    			mount_component(dashboard, target, anchor);
    			current = true;
    		},
    		p: noop,
    		i: function intro(local) {
    			if (current) return;
    			transition_in(dashboard.$$.fragment, local);
    			current = true;
    		},
    		o: function outro(local) {
    			transition_out(dashboard.$$.fragment, local);
    			current = false;
    		},
    		d: function destroy(detaching) {
    			destroy_component(dashboard, detaching);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_if_block$1.name,
    		type: "if",
    		source: "(50:0) {#if tabNum === 0}",
    		ctx
    	});

    	return block;
    }

    function create_fragment$d(ctx) {
    	let t0;
    	let header;
    	let h1;
    	let t2;
    	let t3;
    	let current_block_type_index;
    	let if_block;
    	let if_block_anchor;
    	let current;

    	const tabs = new Tabs({
    			props: {
    				tabNum: /*tabNum*/ ctx[1],
    				names: ["Dashboard", "Editor", "Console", "Admin"]
    			},
    			$$inline: true
    		});

    	tabs.$on("tabChange", /*tabChange_handler*/ ctx[5]);
    	const if_block_creators = [create_if_block$1, create_if_block_1, create_if_block_2, create_if_block_3];
    	const if_blocks = [];

    	function select_block_type(ctx, dirty) {
    		if (/*tabNum*/ ctx[1] === 0) return 0;
    		if (/*tabNum*/ ctx[1] === 1) return 1;
    		if (/*tabNum*/ ctx[1] === 2) return 2;
    		if (/*tabNum*/ ctx[1] === 3) return 3;
    		return -1;
    	}

    	if (~(current_block_type_index = select_block_type(ctx))) {
    		if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
    	}

    	const block = {
    		c: function create() {
    			t0 = space();
    			header = element("header");
    			h1 = element("h1");
    			h1.textContent = "JET dev";
    			t2 = space();
    			create_component(tabs.$$.fragment);
    			t3 = space();
    			if (if_block) if_block.c();
    			if_block_anchor = empty();
    			document.title = "JET dev - JeeLabs";
    			add_location(h1, file$c, 45, 8, 1075);
    			add_location(header, file$c, 45, 0, 1067);
    		},
    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},
    		m: function mount(target, anchor) {
    			insert_dev(target, t0, anchor);
    			insert_dev(target, header, anchor);
    			append_dev(header, h1);
    			insert_dev(target, t2, anchor);
    			mount_component(tabs, target, anchor);
    			insert_dev(target, t3, anchor);

    			if (~current_block_type_index) {
    				if_blocks[current_block_type_index].m(target, anchor);
    			}

    			insert_dev(target, if_block_anchor, anchor);
    			current = true;
    		},
    		p: function update(ctx, [dirty]) {
    			const tabs_changes = {};
    			if (dirty & /*tabNum*/ 2) tabs_changes.tabNum = /*tabNum*/ ctx[1];
    			tabs.$set(tabs_changes);
    			let previous_block_index = current_block_type_index;
    			current_block_type_index = select_block_type(ctx);

    			if (current_block_type_index === previous_block_index) {
    				if (~current_block_type_index) {
    					if_blocks[current_block_type_index].p(ctx, dirty);
    				}
    			} else {
    				if (if_block) {
    					group_outros();

    					transition_out(if_blocks[previous_block_index], 1, 1, () => {
    						if_blocks[previous_block_index] = null;
    					});

    					check_outros();
    				}

    				if (~current_block_type_index) {
    					if_block = if_blocks[current_block_type_index];

    					if (!if_block) {
    						if_block = if_blocks[current_block_type_index] = if_block_creators[current_block_type_index](ctx);
    						if_block.c();
    					}

    					transition_in(if_block, 1);
    					if_block.m(if_block_anchor.parentNode, if_block_anchor);
    				} else {
    					if_block = null;
    				}
    			}
    		},
    		i: function intro(local) {
    			if (current) return;
    			transition_in(tabs.$$.fragment, local);
    			transition_in(if_block);
    			current = true;
    		},
    		o: function outro(local) {
    			transition_out(tabs.$$.fragment, local);
    			transition_out(if_block);
    			current = false;
    		},
    		d: function destroy(detaching) {
    			if (detaching) detach_dev(t0);
    			if (detaching) detach_dev(header);
    			if (detaching) detach_dev(t2);
    			destroy_component(tabs, detaching);
    			if (detaching) detach_dev(t3);

    			if (~current_block_type_index) {
    				if_blocks[current_block_type_index].d(detaching);
    			}

    			if (detaching) detach_dev(if_block_anchor);
    		}
    	};

    	dispatch_dev("SvelteRegisterBlock", {
    		block,
    		id: create_fragment$d.name,
    		type: "component",
    		source: "",
    		ctx
    	});

    	return block;
    }

    function instance$d($$self, $$props, $$invalidate) {
    	setContext("sendMsg", onSendMsg);
    	let ws, onReceive;

    	function connect() {
    		ws = new WebSocket(`ws://${location.host}/live`);

    		ws.onclose = e => {
    			ws = null;
    			if (e.code != 1006) console.log(`WebSocket disconnected, code ${e.code}`);
    			setTimeout(connect, 1000);
    		};

    		ws.onopen = e => {
    			console.info("websocket connected");
    		};

    		ws.onmessage = e => {
    			onReceive(JSON.parse(e.data));
    		};
    	}

    	connect();
    	let tabNum = 1;

    	// TODO messy, should probably put this inside the ws.on... handlers
    	function onSendMsg(...args) {
    		if (ws) ws.send(JSON.stringify(args));
    	}

    	const writable_props = [];

    	Object.keys($$props).forEach(key => {
    		if (!~writable_props.indexOf(key) && key.slice(0, 2) !== "$$") console_2.warn(`<App> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;
    	validate_slots("App", $$slots, []);
    	const tabChange_handler = e => $$invalidate(1, tabNum = e.detail);

    	function editor_onReceive_binding(value) {
    		onReceive = value;
    		$$invalidate(0, onReceive);
    	}

    	$$self.$capture_state = () => ({
    		setContext,
    		Dashboard,
    		Editor,
    		Console,
    		Admin,
    		Tabs,
    		ws,
    		onReceive,
    		connect,
    		tabNum,
    		onSendMsg
    	});

    	$$self.$inject_state = $$props => {
    		if ("ws" in $$props) ws = $$props.ws;
    		if ("onReceive" in $$props) $$invalidate(0, onReceive = $$props.onReceive);
    		if ("tabNum" in $$props) $$invalidate(1, tabNum = $$props.tabNum);
    	};

    	if ($$props && "$$inject" in $$props) {
    		$$self.$inject_state($$props.$$inject);
    	}

    	return [
    		onReceive,
    		tabNum,
    		ws,
    		connect,
    		onSendMsg,
    		tabChange_handler,
    		editor_onReceive_binding
    	];
    }

    class App extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$d, create_fragment$d, safe_not_equal, {});

    		dispatch_dev("SvelteRegisterComponent", {
    			component: this,
    			tagName: "App",
    			options,
    			id: create_fragment$d.name
    		});
    	}
    }

    var app = new App({
    	target: document.body
    });

    return app;

}());
//# sourceMappingURL=bundle.js.map
